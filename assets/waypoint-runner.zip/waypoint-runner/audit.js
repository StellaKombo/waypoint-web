/* Waypoint read-only DOM checks. Runs in Chrome's isolated extension world. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.WaypointAudit = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const LIMIT = 5000;
  function allElements(doc) {
    const result = [];
    const visit = scope => {
      for (const el of scope.querySelectorAll('*')) {
        if (result.length >= LIMIT) return;
        result.push(el);
        if (el.shadowRoot) visit(el.shadowRoot);
      }
    };
    visit(doc);
    return result;
  }
  function visible(el, win) {
    if (!el || el.closest('[hidden],[inert],[aria-hidden="true"]')) return false;
    for (let p = el; p; p = p.parentElement || (p.getRootNode && p.getRootNode().host)) {
      const style = win.getComputedStyle(p);
      if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse' || Number(style.opacity) === 0) return false;
    }
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  const clean = value => String(value || '').replace(/\s+/g, ' ').trim().slice(0, 120);
  function nameOf(el, doc) {
    const aria = clean(el.getAttribute('aria-label'));
    if (aria) return aria;
    const labelledBy = (el.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean);
    const localRoot = el.getRootNode();
    const labelled = clean(labelledBy.map(id => {
      const node = typeof localRoot.getElementById === 'function' ? localRoot.getElementById(id) : doc.getElementById(id);
      return node ? node.textContent : '';
    }).join(' '));
    if (labelled) return labelled;
    if (el.labels && el.labels.length) return clean(Array.from(el.labels).map(x => x.textContent).join(' '));
    if (el.tagName === 'IMG' || el.getAttribute('type') === 'image') return clean(el.getAttribute('alt'));
    // Values are deliberately never inspected, even for submit controls.
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') return clean(el.getAttribute('title'));
    const imgs = Array.from(el.querySelectorAll('img')).map(img => img.getAttribute('alt') || '').join(' ');
    return clean(el.textContent) || clean(imgs) || clean(el.getAttribute('title'));
  }
  function selector(el, win) {
    // CSS paths do not contain page text, input values or attribute secrets.
    const esc = s => win.CSS && win.CSS.escape ? win.CSS.escape(s) : String(s).replace(/[^a-zA-Z0-9_-]/g, ch => '\\' + ch);
    if (el.id) return '#' + esc(el.id);
    const parts = [];
    for (let p = el; p && p.nodeType === 1 && parts.length < 6; p = p.parentElement) {
      let bit = p.tagName.toLowerCase();
      if (p.parentElement) {
        const siblings = Array.from(p.parentElement.children).filter(x => x.tagName === p.tagName);
        if (siblings.length > 1) bit += ':nth-of-type(' + (siblings.indexOf(p) + 1) + ')';
      }
      parts.unshift(bit);
      if (p.id) { parts[0] = '#' + esc(p.id); break; }
    }
    return parts.join(' > ');
  }
  function rectangle(el) {
    const r = el.getBoundingClientRect();
    return Object.fromEntries(['x', 'y', 'width', 'height'].map(k => [k, Math.round((Number(r[k]) || 0) * 100) / 100]));
  }
  function clipped(el, win) {
    const r = el.getBoundingClientRect();
    for (let p = el.parentElement || el.getRootNode().host; p; p = p.parentElement || p.getRootNode().host) {
      if (p === el.ownerDocument.documentElement || p === el.ownerDocument.body) continue;
      const s = win.getComputedStyle(p);
      if (/^(hidden|clip|auto|scroll)$/.test(s.overflowX || s.overflow)) {
        const box = p.getBoundingClientRect();
        if (r.left < box.left - 1 || r.right > box.right + 1) return true;
      }
    }
    return false;
  }
  function run(options = {}, doc = globalThis.document, win = doc.defaultView) {
    if (!doc || !win) throw new Error('A page document is required.');
    const nodes = allElements(doc), findings = [], checks = [];
    const visibleNodes = nodes.filter(el => visible(el, win));
    const width = win.innerWidth || doc.documentElement.clientWidth;
    const add = (category, title, detail, severity, kind, el, recommendation) => {
      if (findings.length >= 100) return;
      const f = {id: 'dom-' + (findings.length + 1), category, title, detail, severity, kind, recommendation};
      if (el) {
        f.selector = selector(el, win);
        f.evidence = { rectangle: rectangle(el), source: 'live-dom', shadowDOM: el.getRootNode() !== doc };
        if (f.evidence.shadowDOM) f.detail += ' This element is inside an open shadow root; its selector is local to that root.';
      }
      findings.push(f);
    };
    const overflow = visibleNodes.filter(el => {
      if (el === doc.documentElement || el === doc.body) return false;
      const r = el.getBoundingClientRect();
      return r.bottom > 0 && r.top < win.innerHeight && (r.right > width + 2 || r.left < -2) && !clipped(el, win);
    });
    const scrollWidth = Math.max(doc.documentElement.scrollWidth || 0, doc.body ? doc.body.scrollWidth : 0);
    const hasOverflow = scrollWidth > width + 2;
    if (hasOverflow) {
      const candidates = overflow.filter(el => !overflow.some(parent => parent !== el && parent.contains(el))).slice(0, 8);
      if (candidates.length) candidates.forEach(el => add('layout', 'Horizontal page overflow', 'This visible element extends beyond the ' + width + ' px viewport, and the page is horizontally scrollable.', 'medium', 'bug', el, 'Constrain width or reflow this element at the current viewport.'));
      else add('layout', 'Horizontal page overflow', 'Document width is ' + scrollWidth + ' px at a ' + width + ' px viewport. Pseudo-elements or off-screen content may be responsible.', 'medium', 'bug', null, 'Inspect page width and responsive containers.');
    }
    checks.push({name: 'Horizontal overflow', status: hasOverflow ? 'fail' : 'pass', detail: 'Document ' + scrollWidth + ' px; viewport ' + width + ' px. Only the current viewport was checked.'});
    let broken = 0;
    for (const el of visibleNodes.filter(el => el.tagName === 'IMG')) {
      if (el.complete && el.naturalWidth === 0 && (el.currentSrc || el.getAttribute('src') || el.getAttribute('srcset'))) {
        broken++;
        add('images', 'Image did not decode', 'A visible image finished loading with zero intrinsic width.', 'medium', 'bug', el, 'Verify its resource URL, image format, and fallback state.');
      }
    }
    checks.push({name: 'Visible images', status: broken ? 'fail' : 'pass', detail: broken + ' failed image(s). Pending and hidden images are excluded.'});
    let missing = 0;
    const controls = visibleNodes.filter(el => el.matches('button,a[href],input:not([type="hidden"]),select,textarea,[role="button"],[role="link"],[role="checkbox"],[role="switch"],[role="combobox"],[role="textbox"]'));
    for (const el of controls) {
      if (!nameOf(el, doc)) {
        const isInput = el.matches('input,select,textarea,[role="textbox"],[role="combobox"]');
        // Submit/reset values can supply accessible names, but we do not read them.
        if (el.matches('input[type="submit"],input[type="reset"],input[type="button"]')) continue;
        missing++;
        add('accessibility', isInput ? 'Form control needs a programmatic label' : 'Interactive control has no detected accessible name', 'No associated label, aria-label, aria-labelledby, title, or usable control text was detected.', 'high', 'bug', el, isInput ? 'Associate a visible label using for/id or use aria-labelledby.' : 'Provide a concise accessible name that describes the action.');
      }
    }
    checks.push({name: 'Control names and labels', status: missing ? 'fail' : 'pass', detail: missing + ' missing detected name(s). This is a DOM heuristic, not a complete accessibility tree audit.'});
    const meta = doc.querySelector('meta[name="viewport" i]');
    if (!meta || !/width\s*=\s*device-width/i.test(meta.content || '')) add('responsive', 'Review mobile viewport configuration', 'No viewport meta declaration with width=device-width was detected.', 'medium', 'suggestion', null, 'For mobile web, declare an appropriate responsive viewport.');
    checks.push({name: 'Mobile viewport metadata', status: meta && /width\s*=\s*device-width/i.test(meta.content || '') ? 'pass' : 'warning', detail: meta ? clean(meta.content) : 'Viewport metadata absent.'});
    const minimum = Math.max(24, Math.min(64, Number(options.minTouchTarget) || 44));
    let small = 0;
    for (const el of controls) {
      if (el.matches(':disabled,[aria-disabled="true"],input[type="checkbox"],input[type="radio"]')) continue;
      const r = el.getBoundingClientRect();
      if (r.bottom <= 0 || r.top >= win.innerHeight || r.right <= 0 || r.left >= width) continue;
      // Inline prose links can meet spacing exceptions; do not flag as confirmed defects.
      if (r.width < minimum || r.height < minimum) {
        small++;
        if (small <= 8) add('usability', 'Review a small touch target', 'This control measures ' + Math.round(r.width) + ' × ' + Math.round(r.height) + ' px, below the ' + minimum + ' px review threshold on at least one axis. Spacing and equivalent controls may make it acceptable.', 'low', 'suggestion', el, 'Review touch use and spacing; consider a larger hit area.');
      }
    }
    checks.push({name: 'Touch target review', status: small ? 'warning' : 'pass', detail: small + ' control(s) below the ' + minimum + ' px review threshold; accessibility exceptions were not evaluated.'});
    const iframeCount = nodes.filter(el => el.tagName === 'IFRAME').length;
    checks.push({name: 'Embedded frames', status: iframeCount ? 'not-tested' : 'pass', detail: iframeCount ? iframeCount + ' frame(s) excluded; their contents require separate testing.' : 'No embedded frames detected.'});
    checks.push({name: 'Coverage', status: 'not-tested', detail: 'Current DOM only. Authentication, server behavior, native devices, closed shadow roots, full WCAG conformance and other routes require separate tests.'});
    if (nodes.length === LIMIT) checks.push({name: 'Scan limit', status: 'warning', detail: 'Scan capped at ' + LIMIT + ' elements.'});
    return { findings, checks, stats: {scanned: nodes.length, visible: visibleNodes.length, controls: controls.length, findings: findings.length, truncated: nodes.length === LIMIT}, viewport: {width, height: win.innerHeight, devicePixelRatio: win.devicePixelRatio || 1} };
  }
  return {run, visible, nameOf, selector};
});
