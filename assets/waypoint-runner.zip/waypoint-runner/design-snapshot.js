/* Passive, bounded evidence capture. No stylesheets, assets, form values or source code. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.WaypointDesignSnapshot = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const OMIT = 'script,style,noscript,template,input,textarea,select,[contenteditable]';
  const privateText = value => String(value || '').slice(0,600).replace(/https?:\/\/\S+|\bwww\.\S+/gi, '[link omitted]').replace(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/gi, '[email omitted]').replace(/\bBearer\s+[^\s,;]+/gi, '[secret omitted]').replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, '[secret omitted]').replace(/\b(?:sk-|gh[pousr]_|github_pat_)[A-Za-z0-9_-]+\b/g, '[secret omitted]').replace(/\b(?:token|password|secret|api[_ -]?key)\s*[:=]\s*\S+/gi, '[secret omitted]').replace(/\b[A-Za-z0-9_-]{32,}\b/g, '[identifier omitted]').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);
  const color = value => /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\([\d.,%\s+\/-]+\)|transparent|currentcolor)$/i.test(String(value || '')) ? String(value).slice(0, 80) : '';
  const length = value => /^(?:(?:-?\d+(?:\.\d+)?(?:px|rem|em|%|vh|vw)?)(?:\s+|$)){1,4}$|^(?:normal|auto|none)$/i.test(String(value || '')) ? String(value).slice(0, 80) : '';
  const font = value => /^[\w\s,'".-]{1,120}$/.test(String(value || '')) && !/url|https|@/i.test(value) ? privateText(value) : '';
  function blocked(el) {
    let depth = 0;
    for (let node = el; node; node = node.parentElement) {
      if (++depth > 32 || node.matches('script,style,noscript,template,[contenteditable]') || node.hasAttribute('hidden') || node.hasAttribute('inert') || node.getAttribute('aria-hidden') === 'true') return true;
      if (node !== el && node.matches('input,textarea,select')) return true;
    }
    return false;
  }
  function visibleTextNode(el) {
    if (!el || blocked(el) || el.matches(OMIT)) return false;
    const win = el.ownerDocument?.defaultView;
    if (!win) return false;
    for (let node = el; node; node = node.parentElement) {
      const style = win.getComputedStyle(node);
      if (style.display === 'none' || ['hidden','collapse'].includes(style.visibility) || Number(style.opacity) === 0) return false;
    }
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.x + r.width > 0 && r.y + r.height > 0 && r.x < win.innerWidth && r.y < win.innerHeight;
  }
  function text(el) {
    if (!visibleTextNode(el)) return '';
    // Traverse only bounded child nodes and skip editable subtrees before reading text.
    let result = '', visited = 0;
    const walk = (node, depth) => {
      if (depth > 3 || ++visited > 80 || result.length >= 240) return;
      if (node.nodeType === 3) { result += ' ' + String(node.textContent || '').slice(0, 240); return; }
      if (node.nodeType !== 1 || !visibleTextNode(node)) return;
      const children = node.childNodes || [];
      for (let index = 0; index < Math.min(children.length, 40); index++) walk(children[index], depth + 1);
    };
    walk(el, 0);
    return privateText(result);
  }
  function name(el, doc) {
    const aria = privateText(el.getAttribute('aria-label'));
    if (aria) return aria;
    const refs = (el.getAttribute('aria-labelledby') || '').slice(0, 512).split(/\s+/).filter(Boolean).slice(0, 8);
    const labelled = privateText(refs.map(id => text(doc.getElementById(id))).join(' '));
    if (labelled) return labelled;
    const labels = privateText(Array.from(el.labels || []).slice(0, 8).map(text).join(' '));
    if (labels) return labels;
    if (el.matches('input,textarea,select')) return privateText(el.getAttribute('title')) || el.tagName.toLowerCase();
    return text(el) || privateText(el.getAttribute('alt')) || privateText(el.getAttribute('title'));
  }
  function run(options = {}, doc = globalThis.document, win = doc.defaultView) {
    if (!doc || !win || !doc.body) throw new Error('The visible app document is unavailable.');
    const origin = new URL(doc.location.href).origin;
    if (!/^https?:\/\//.test(origin)) throw new Error('An authorized HTTP app is required.');
    const width = Math.max(1, Math.min(10000, Number(win.innerWidth) || 1)), height = Math.max(1, Math.min(10000, Number(win.innerHeight) || 1));
    const now = () => win.performance?.now?.() ?? Date.now(), started = now();
    const maxElements = 150, maxScanned = 3000, maxMs = 100;
    const tokens = {colors: [], fonts: [], fontSizes: [], radii: [], spacing: []}, elements = [], seen = new Map();
    const addToken = (key, value) => { if (value && tokens[key].length < 24 && !tokens[key].includes(value)) tokens[key].push(value); };
    const walker = doc.createTreeWalker(doc.body, 1); let el, scanned = 0, truncated = false;
    while ((el = walker.nextNode())) {
      if (++scanned > maxScanned || now() - started >= maxMs || elements.length >= maxElements) { truncated = true; break; }
      if (blocked(el) || el.matches('input[type="hidden"]')) continue;
      const r = el.getBoundingClientRect();
      if (![r.x, r.y, r.width, r.height].every(Number.isFinite) || r.width <= 0 || r.height <= 0 || r.x + r.width <= 0 || r.y + r.height <= 0 || r.x >= width || r.y >= height) continue;
      let visible = true, depth = 0;
      for (let p = el; p && depth++ < 32; p = p.parentElement) {
        const s = win.getComputedStyle(p);
        if (s.display === 'none' || ['hidden', 'collapse'].includes(s.visibility) || Number(s.opacity) === 0) { visible = false; break; }
      }
      if (!visible) continue;
      const s = win.getComputedStyle(el), tag = el.tagName.toLowerCase();
      const inputType = tag === 'input' ? (el.getAttribute('type') || 'text').toLowerCase() : '';
      const inputRole = {checkbox:'checkbox',radio:'radio',range:'slider',number:'spinbutton',button:'button',submit:'button',reset:'button'}[inputType] || 'textbox';
      const role = privateText(el.getAttribute('role')) || (tag === 'input' ? inputRole : tag === 'a' ? (el.hasAttribute('href') ? 'link' : '') : {button:'button',textarea:'textbox',select:'combobox',nav:'navigation',main:'main',img:'img'}[tag] || (/^h[1-6]$/.test(tag) ? 'heading' : ''));
      const control = el.matches('button,a[href],input,textarea,select,[role="button"],[role="link"],[role="checkbox"],[role="switch"]');
      const heading = /^h[1-6]$/.test(tag) || role === 'heading';
      const region = el.matches('main,nav,header,footer,section,article,aside,form') || ['main','navigation','region','dialog','banner','contentinfo'].includes(role) || ['flex','inline-flex','grid','inline-grid'].includes(s.display);
      const label = name(el, doc);
      if (!control && !heading && !region && tag !== 'img' && (!label || el.children?.length)) continue;
      const id = `element-${elements.length + 1}`; let parentId = null;
      for (let p = el.parentElement; p; p = p.parentElement) { if (seen.has(p)) { parentId = seen.get(p); break; } }
      const style = {display: ['block','inline','inline-block','flex','inline-flex','grid','inline-grid','table','list-item'].includes(s.display) ? s.display : 'block', layout: /grid/.test(s.display) ? 'grid' : /flex/.test(s.display) ? `flex-${s.flexDirection === 'column' || s.flexDirection === 'column-reverse' ? 'column' : 'row'}` : 'flow', fontFamily: font(s.fontFamily), fontSize: length(s.fontSize), fontWeight: /^(?:[1-9]00|normal|bold)$/.test(String(s.fontWeight || '')) ? String(s.fontWeight) : '', lineHeight: length(s.lineHeight), color: color(s.color), backgroundColor: color(s.backgroundColor), borderColor: color(s.borderColor), borderRadius: length(s.borderRadius), gap: length(s.gap), padding: length(s.padding)};
      const x = Math.max(0, r.x), y = Math.max(0, r.y), bounds = {x,y,width:Math.min(width,r.x+r.width)-x,height:Math.min(height,r.y+r.height)-y};
      const round = value => Math.round(value * 10) / 10;
      for (const key of Object.keys(bounds)) bounds[key] = round(bounds[key]);
      elements.push({id,parentId,tag,role,name:label,bounds,style,kind:control?'control':heading?'heading':region?'region':tag==='img'?'image':'text'}); seen.set(el,id);
      for (const value of [style.color,style.backgroundColor,style.borderColor]) addToken('colors',value);
      addToken('fonts',style.fontFamily); addToken('fontSizes',style.fontSize); addToken('radii',style.borderRadius); addToken('spacing',style.gap); addToken('spacing',style.padding);
    }
    return {schema:'waypoint.design.v1',origin,title:privateText(doc.title),capturedAt:new Date().toISOString(),viewport:{width,height},elements,tokens,capture:{scanned:Math.min(scanned,maxScanned),emitted:elements.length,truncated,durationMs:Math.max(0,Math.round(now()-started))},limitations:['Visible main document at one viewport only; no iframe, shadow DOM or offscreen coverage.','Only app origin retained; no form values, editable content, page paths, query strings, asset URLs, assets, stylesheets or original source code collected.','Static interface labels can contain user content; review evidence before exporting.','Observed appearance does not establish backend behavior or original implementation.']};
  }
  return {version:1,run};
});
