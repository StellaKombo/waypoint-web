'use strict';
importScripts('protocol-utils.js');
const { DASHBOARD_ORIGIN, PRESETS, cleanUrl, allowedOrigin, trustedSender, boundedText, validateSteps } = WaypointProtocol;
const SESSION_KEY = 'waypoint-session-v1';
let session = null;
let restoration = null;
let queue = Promise.resolve();
let stopping = false;
let ending = null;
let telemetry = { consoleErrors: [], networkFailures: [] };
let localAgent = null;
let polling = false;
let controlPolling = false;
let dashboardOwner = null;
let runningSource = null;
let actionGeneration = 0;
const ports = new Set();
const pendingRequests = new Map();

function failure(code, message) { return Object.assign(new Error(message), { code }); }
function call(api, ...args) {
  return new Promise((resolve, reject) => api(...args, result => {
    const err = chrome.runtime.lastError;
    if (err) reject(failure('CHROME_API', err.message)); else resolve(result);
  }));
}
function publicSession() {
  if (!session) return null;
  const { id, tabId, origin, url, title, connectedAt, consent, viewport, recording, steps } = session;
  return { id, tabId, origin, url, title, connectedAt, consent, viewport, recording, steps };
}
function status() { return { connected: Boolean(session), session: publicSession(), agentPaired: Boolean(localAgent), capabilities: session ? session.consent : { inspect: false, screenshot: false, control: false } }; }
function emit(event, data) {
  for (const port of ports) { try { port.postMessage({ event, data }); } catch (_) { ports.delete(port); } }
}
async function persist() { await call(chrome.storage.session.set.bind(chrome.storage.session), { [SESSION_KEY]: session }); }
async function restore() {
  if (!restoration) restoration = (async () => {
    const saved = await call(chrome.storage.session.get.bind(chrome.storage.session), [SESSION_KEY, 'waypoint-agent-v1']);
    const candidate = saved?.[SESSION_KEY];
    if (!candidate || !allowedOrigin(candidate.origin) || !Number.isInteger(candidate.tabId)) { await call(chrome.storage.session.remove.bind(chrome.storage.session), [SESSION_KEY,'waypoint-agent-v1']); return; }
    try {
      const tab = await call(chrome.tabs.get.bind(chrome.tabs), candidate.tabId);
      if (new URL(tab.url).origin !== candidate.origin) {
        await call(chrome.storage.session.remove.bind(chrome.storage.session), [SESSION_KEY,'waypoint-agent-v1']); return;
      }
      // Probe our stored target only. This also verifies debugger ownership,
      // without enumerating other tabs or exposing their metadata.
      await call(chrome.debugger.sendCommand.bind(chrome.debugger), {tabId:candidate.tabId}, 'Page.getLayoutMetrics', {});
      session = candidate; session.url = cleanUrl(tab.url); session.title = tab.title || session.title;
      localAgent = saved['waypoint-agent-v1'] || null;
      telemetry = { consoleErrors: [], networkFailures: [] };
      emit('session', status());
      if (localAgent) { setTimeout(pollAgent, 0); setTimeout(pollAgentControl, 0); }
    } catch (_) { await call(chrome.storage.session.remove.bind(chrome.storage.session), [SESSION_KEY,'waypoint-agent-v1']); }
  })();
  await restoration;
}
async function current(capability, expectedId) {
  await restore();
  if (!session || stopping) throw failure('NO_SESSION', 'Open the app tab, click the Waypoint extension and authorize a session.');
  if (expectedId && session.id !== expectedId) throw failure('SESSION_CHANGED', 'The approved session changed. Start the action again.');
  if (capability && !session.consent[capability]) throw failure('CONSENT_REQUIRED', `Enable ${capability} consent in the Waypoint popup on the app tab.`);
  let tab;
  try { tab = await call(chrome.tabs.get.bind(chrome.tabs), session.tabId); } catch (_) { await end('The app tab was closed.'); throw failure('NO_SESSION', 'The app tab is no longer available.'); }
  if (!tab.url || new URL(tab.url).origin !== session.origin) { await end('The app navigated to a different origin.'); throw failure('ORIGIN_CHANGED', 'The app changed origin. Select and authorize it again.'); }
  session.url = cleanUrl(tab.url); session.title = tab.title || '';
  return session;
}
async function cdp(method, params = {}, expectedId) {
  const s = await current(undefined, expectedId);
  return call(chrome.debugger.sendCommand.bind(chrome.debugger), { tabId: s.tabId }, method, params);
}
async function inject(files, expectedId) {
  const s = await current('inspect', expectedId);
  await call(chrome.scripting.executeScript.bind(chrome.scripting), { target: { tabId: s.tabId, allFrames: false }, files });
}
async function execute(func, args = [], capability = 'inspect', expectedId) {
  const s = await current(capability, expectedId);
  const results = await call(chrome.scripting.executeScript.bind(chrome.scripting), { target: { tabId: s.tabId, allFrames: false }, func, args });
  if (!results?.length) throw failure('PAGE_UNAVAILABLE', 'The app document is unavailable. Try again after it finishes loading.');
  return results[0].result;
}
async function engine(method, args = [], expectedId) {
  await inject(['engine.js'], expectedId);
  return execute(async (name, params) => {
    if (!globalThis.WaypointEngine || typeof globalThis.WaypointEngine[name] !== 'function') throw new Error(`Missing engine method ${name}`);
    return await globalThis.WaypointEngine[name](...params);
  }, [method, args], 'inspect', expectedId);
}
async function end(reason = 'Session ended.', notifyAgentBridge = true) {
  await restore();
  if (ending) return ending;
  ending = endSession(reason, notifyAgentBridge);
  try { return await ending; } finally { ending = null; }
}
async function endSession(reason, notifyAgentBridge) {
  const old = session;
  const oldAgent = localAgent;
  stopping = true; session = null;
  actionGeneration++;
  localAgent = null;
  telemetry = { consoleErrors: [], networkFailures: [] }; pendingRequests.clear();
  await call(chrome.storage.session.remove.bind(chrome.storage.session), [SESSION_KEY, 'waypoint-agent-v1']).catch(() => {});
  chrome.alarms.clear('waypoint-agent-poll');
  if (old) {
    await call(chrome.scripting.executeScript.bind(chrome.scripting), { target: { tabId: old.tabId }, func: () => { globalThis.WaypointEngine?.stopRecording?.(); globalThis.WaypointEngine?.cancel?.(); } }).catch(() => {});
    await call(chrome.debugger.sendCommand.bind(chrome.debugger), { tabId: old.tabId }, 'Emulation.clearDeviceMetricsOverride', {}).catch(() => {});
    await call(chrome.debugger.sendCommand.bind(chrome.debugger), { tabId: old.tabId }, 'Emulation.setTouchEmulationEnabled', {enabled:false}).catch(() => {});
    await call(chrome.debugger.detach.bind(chrome.debugger), { tabId: old.tabId }).catch(() => {});
  }
  if (oldAgent && notifyAgentBridge) await agentFetch('/bridge/unpair', { method:'POST', body:'{}' }, 3000, oldAgent.token).catch(() => {});
  stopping = false;
  emit('session', { ...status(), reason });
  return { ...status(), reason };
}
async function authorize(payload) {
  await restore();
  if (ending) await ending;
  if (!Number.isInteger(payload?.tabId)) throw failure('INVALID_REQUEST', 'Select an app tab first.');
  const tab = await call(chrome.tabs.get.bind(chrome.tabs), payload.tabId);
  if (!allowedOrigin(tab.url)) throw failure('INVALID_ORIGIN', 'Choose an HTTP or HTTPS app tab, separate from the Waypoint dashboard.');
  const consent = { inspect: payload.consent?.inspect === true, screenshot: payload.consent?.screenshot === true, control: payload.consent?.control === true };
  if (!consent.inspect) throw failure('CONSENT_REQUIRED', 'Page inspection consent is required to establish a testing session.');
  if (session) await end('Replaced by a newly approved session.');
  await call(chrome.debugger.attach.bind(chrome.debugger), { tabId: tab.id }, '1.3');
  session = { id: crypto.randomUUID(), tabId: tab.id, origin: new URL(tab.url).origin, url: cleanUrl(tab.url), title: tab.title || '', connectedAt: new Date().toISOString(), consent, viewport: { preset: 'current', width: 0, height: 0, deviceScaleFactor: 1, mobile: false }, recording: false, steps: [] };
  try {
    await cdp('Runtime.enable'); await cdp('Network.enable'); await cdp('Page.enable');
    session.viewport = await execute(() => ({ preset: 'current', width: innerWidth, height: innerHeight, deviceScaleFactor: devicePixelRatio, mobile: false }));
    await persist(); emit('session', status()); return status();
  } catch (err) { await end('Unable to initialize the browser session.'); throw err; }
}
function ensureSafe(verdict) {
  if (!verdict || verdict.safe !== true) throw failure('GUARDED_ACTION', verdict?.reason || 'This action requires manual interaction in the app.');
}
async function dispatch(command, payload = {}, source) {
  await restore();
  if (command === 'status') {
    if (session) await current();
    return status();
  }
  if (command === 'stop') return end('Session ended.', source !== 'agent');
  const s = await current();
  if (command === 'audit') {
    await current('inspect', s.id); await inject(['audit.js'], s.id);
    const audit = await execute(async () => await globalThis.WaypointAudit.run(), [], 'inspect', s.id);
    if (Number.isFinite(audit.viewport?.width) && Number.isFinite(audit.viewport?.height)) s.viewport = { ...s.viewport, width: audit.viewport.width, height: audit.viewport.height };
    return { schema: 'waypoint.report.v1', id: crypto.randomUUID(), url: s.url, title: s.title, createdAt: new Date().toISOString(), viewport: s.viewport, findings: audit.findings || [], checks: audit.checks || [], stats: audit.stats || {}, telemetry: structuredClone(telemetry) };
  }
  if (command === 'screenshot') {
    await current('screenshot', s.id);
    const dimensions = await execute(() => ({ width: innerWidth, height: innerHeight, deviceScaleFactor: devicePixelRatio }), [], 'inspect', s.id);
    const capture = await cdp('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false }, s.id);
    const viewport = { ...s.viewport, ...dimensions };
    s.viewport = viewport; await persist();
    return { id: crypto.randomUUID(), capturedAt: new Date().toISOString(), dataUrl: `data:image/png;base64,${capture.data}`, width: viewport.width, height: viewport.height, viewport };
  }
  if (command === 'viewport') {
    await current('control', s.id);
    if (!Object.hasOwn(PRESETS, payload.preset)) throw failure('INVALID_REQUEST', 'Choose desktop or mobile viewport.');
    const preset = PRESETS[payload.preset];
    await cdp('Emulation.setDeviceMetricsOverride', { width: preset.width, height: preset.height, deviceScaleFactor: preset.deviceScaleFactor, mobile: preset.mobile }, s.id);
    await cdp('Emulation.setTouchEmulationEnabled', { enabled: preset.mobile, maxTouchPoints: 1 }, s.id);
    s.viewport = { ...preset }; await persist(); emit('session', status()); return s.viewport;
  }
  if (command === 'click') {
    await current('control', s.id);
    const { x, y } = payload;
    if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0) throw failure('INVALID_REQUEST', 'Click coordinates must be nonnegative CSS pixels.');
    ensureSafe(await engine('inspectPoint', [{ x, y }], s.id));
    await cdp('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y }, s.id);
    await cdp('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 }, s.id);
    await cdp('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 }, s.id);
    return { performed: true };
  }
  if (command === 'type') {
    await current('control', s.id);
    const text = boundedText(payload.text, 2000);
    ensureSafe(await engine('inspectFocus', [{ intent: 'type' }], s.id));
    await cdp('Input.insertText', { text }, s.id); return { performed: true };
  }
  if (command === 'key') {
    await current('control', s.id);
    const codes = { Enter: 13, Tab: 9, Escape: 27, Backspace: 8, ArrowUp: 38, ArrowDown: 40, ArrowLeft: 37, ArrowRight: 39 };
    if (!Object.hasOwn(codes, payload.key)) throw failure('INVALID_REQUEST', 'Choose a supported navigation key.');
    ensureSafe(await engine('inspectFocus', [{ intent: 'key', key: payload.key }], s.id));
    await cdp('Input.dispatchKeyEvent', { type: 'keyDown', key: payload.key, code: payload.key, windowsVirtualKeyCode: codes[payload.key], nativeVirtualKeyCode: codes[payload.key] }, s.id);
    await cdp('Input.dispatchKeyEvent', { type: 'keyUp', key: payload.key, code: payload.key, windowsVirtualKeyCode: codes[payload.key], nativeVirtualKeyCode: codes[payload.key] }, s.id);
    return { performed: true };
  }
  if (command === 'assertText') {
    const text = boundedText(payload.text, 300, 'Assertion text');
    const result = await engine('run', [{ steps: [{ type: 'assertText', text }], timeoutMs: 5000 }], s.id);
    return { passed: result.passed ?? result.status === 'passed', text, detail: result.results?.[0]?.detail || result.steps?.[0]?.detail || (result.status === 'passed' ? 'Expected text is visible.' : 'Expected text is not visible.') };
  }
  if (command === 'recordStart') {
    await current('control', s.id);
    s.recording = true; s.recordingBy = runningSource === 'agent' ? 'agent' : 'dashboard'; s.steps = []; await persist();
    try { await startPageRecording(s.id); } catch (err) { s.recording = false; await persist(); throw err; }
    const recording = { recording: true, steps: s.steps }; emit('recording', recording); return recording;
  }
  if (command === 'recordStop') {
    await current('control', s.id);
    await engine('stopRecording', [], s.id);
    s.recording = false; await persist();
    const recording = { recording: false, steps: s.steps }; emit('recording', recording); return recording;
  }
  if (command === 'replay') {
    await current('control', s.id);
    const steps = validateSteps(payload.steps);
    const started = Date.now();
    const token = ++actionGeneration, results = [];
    const delayMs = Math.max(0, Math.min(2000, Number(payload.delayMs) || 350));
    for (let index = 0; index < steps.length; index++) {
      if (token !== actionGeneration) { results.push({index,type:steps[index].type,status:'blocked',detail:'Replay was stopped.'}); break; }
      await waitForPage(s.id, token);
      let result;
      try { result = await engine('run', [{ steps: [steps[index]], timeoutMs: 5000, delayMs: 0 }], s.id); }
      catch (err) {
        results.push({ index, type: steps[index].type, label: steps[index].label || steps[index].text || '', status: 'blocked', detail: `The document changed or became unavailable during this step. Inspect the app before retrying. ${err.message}` }); break;
      }
      const item = (result.results || result.steps || [])[0] || {status:'blocked', detail:'No step result was returned.'};
      results.push({ ...item, index, type: steps[index].type, label: item.label || steps[index].label || steps[index].text || '', status: item.status || (item.passed ? 'pass' : 'fail'), detail: item.detail || item.message || '' });
      if (!result.passed || token !== actionGeneration) break;
      if (index < steps.length - 1) await new Promise(resolve => setTimeout(resolve, delayMs));
    }
    return { passed: results.length === steps.length && results.every(item => ['pass','passed'].includes(item.status)), results, elapsedMs: Date.now() - started, findings: [] };
  }
  if (command === 'scroll') {
    await current('control', s.id);
    const dimensions = await execute(() => ({ width: innerWidth, height: innerHeight }), [], 'inspect', s.id);
    const x = Number.isFinite(payload.x) ? payload.x : Math.round(dimensions.width / 2);
    const y = Number.isFinite(payload.y) ? payload.y : Math.round(dimensions.height / 2);
    if (x < 0 || y < 0 || x >= dimensions.width || y >= dimensions.height) throw failure('INVALID_REQUEST', 'Scroll coordinates are outside the viewport.');
    const deltaY = Math.max(-2000, Math.min(2000, Number(payload.deltaY) || 0));
    const deltaX = Math.max(-2000, Math.min(2000, Number(payload.deltaX) || 0));
    await cdp('Input.dispatchMouseEvent', { type: 'mouseWheel', x, y, deltaX, deltaY }, s.id);
    return { performed: true };
  }
  if (command === 'designSnapshot') {
    await inject(['design-snapshot.js'], s.id);
    const snapshot = await execute(() => globalThis.WaypointDesignSnapshot.run(), [], 'inspect', s.id);
    // Drop evidence if Stop, a new session or navigation won the capture race.
    const active = await current('inspect', s.id);
    if (snapshot?.origin !== active.origin) throw failure('ORIGIN_CHANGED', 'The app changed origin during capture.');
    return snapshot;
  }
  if (command === 'observe' || command === 'inspect') {
    await inject(['engine.js'], s.id);
    return execute(() => {
      const controls = [];
      for (const el of document.querySelectorAll('button,a[href],input:not([type="hidden"]),textarea,select,[role="button"],[role="link"]')) {
        const r = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        if (r.width <= 0 || r.height <= 0 || r.bottom <= 0 || r.top >= innerHeight || r.right <= 0 || r.left >= innerWidth || style.visibility === 'hidden' || style.display === 'none') continue;
        const v = globalThis.WaypointEngine.verdict(el);
        controls.push({ type: el.tagName.toLowerCase(), role: el.getAttribute('role') || el.tagName.toLowerCase(), label: (v.label || el.getAttribute('aria-label') || el.getAttribute('title') || el.tagName.toLowerCase()).slice(0,120), selector: v.selector || null, safe: v.safe, reason: v.reason || '', rectangle: { x: r.x, y: r.y, width: r.width, height: r.height } });
        if (controls.length >= 150) break;
      }
      const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
      let node, visibleText = '';
      while ((node = walker.nextNode()) && visibleText.length < 3000) {
        const parent = node.parentElement;
        if (!parent || parent.closest('script,style,noscript,template,input,textarea,select,[contenteditable]')) continue;
        const r = parent.getBoundingClientRect(), style = getComputedStyle(parent);
        if (r.width <= 0 || r.height <= 0 || r.bottom <= 0 || r.top >= innerHeight || r.right <= 0 || r.left >= innerWidth || style.visibility === 'hidden' || style.display === 'none') continue;
        if (!globalThis.WaypointEngine.verdict(parent).safe) continue;
        visibleText += ' ' + node.textContent.replace(/\s+/g,' ').trim();
      }
      return { viewport: { width: innerWidth, height: innerHeight }, controls, visibleText: visibleText.trim().slice(0,3000), limitations: ['Main document visible controls only.', 'No form values or hidden text collected.'] };
    }, [], 'inspect', s.id);
  }
  throw failure('UNKNOWN_COMMAND', 'This bridge command is unsupported.');
}
function queued(work) {
  const result = queue.then(work, work);
  queue = result.catch(() => {}); return result;
}
async function waitForPage(expectedId, generation) {
  const deadline = Date.now() + 10000;
  for (;;) {
    if (generation !== actionGeneration) throw failure('REPLAY_STOPPED', 'The replay was stopped.');
    const s = await current(undefined, expectedId);
    const tab = await call(chrome.tabs.get.bind(chrome.tabs), s.tabId);
    if (tab.status !== 'loading') return;
    if (Date.now() >= deadline) throw failure('PAGE_TIMEOUT', 'The app is still loading. Inspect it before replaying again.');
    await new Promise(resolve => setTimeout(resolve, 100));
  }
}
async function startPageRecording(expectedId) {
  await inject(['engine.js'], expectedId);
  if (!session?.recording || session.id !== expectedId) return;
  await execute(id => {
    globalThis.WaypointEngine.setRecordingSink(step => chrome.runtime.sendMessage({ command: 'recordStep', payload: { sessionId: id, step } }, () => { void chrome.runtime.lastError; }));
    return globalThis.WaypointEngine.startRecording();
  }, [expectedId], 'inspect', expectedId);
}
const AGENT_URL = 'http://127.0.0.1:4242';
async function agentFetch(path, options = {}, timeoutMs = 25000, token = localAgent?.token) {
  if (!token) throw failure('AGENT_NOT_PAIRED', 'Pair a local AI agent in the extension popup first.');
  const response = await fetch(`${AGENT_URL}${path}`, { ...options, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'X-Waypoint-Extension-Id': chrome.runtime.id, ...options.headers }, signal: AbortSignal.timeout(timeoutMs), redirect: 'error', cache: 'no-store', credentials: 'omit' });
  if (!response.ok) throw Object.assign(failure('AGENT_HTTP', `Local agent bridge returned HTTP ${response.status}.`), {httpStatus:response.status});
  return response.status === 204 ? null : response.json();
}
async function pairAgent(payload) {
  const s = await current();
  if (payload.consent !== true) throw failure('CONSENT_REQUIRED', 'Explicitly allow your local AI agent to use this approved app session.');
  if (typeof payload.token !== 'string' || !/^[a-fA-F0-9]{64}$/.test(payload.token)) throw failure('INVALID_TOKEN', 'Paste the 64-character pairing token printed by your local bridge.');
  await agentFetch('/bridge/pair', { method: 'POST', body: JSON.stringify({ extensionId: chrome.runtime.id }) }, 5000, payload.token);
  await current(undefined, s.id);
  localAgent = { token: payload.token, sessionId: s.id };
  await call(chrome.storage.session.set.bind(chrome.storage.session), { 'waypoint-agent-v1': localAgent });
  await chrome.alarms.create('waypoint-agent-poll', { periodInMinutes: 0.5 });
  emit('session', status()); setTimeout(pollAgent, 0); setTimeout(pollAgentControl, 0);
  return { paired: true, endpoint: AGENT_URL };
}
async function unpairAgent() {
  const oldToken = localAgent?.token;
  localAgent = null;
  if (runningSource === 'agent') actionGeneration++;
  if (runningSource === 'agent' && session) await execute(() => globalThis.WaypointEngine?.cancel?.(), [], 'inspect', session.id).catch(() => {});
  await call(chrome.storage.session.remove.bind(chrome.storage.session), 'waypoint-agent-v1');
  await chrome.alarms.clear('waypoint-agent-poll');
  if (oldToken) await agentFetch('/bridge/unpair', { method: 'POST', body: '{}' }, 3000, oldToken).catch(() => {});
  emit('session', status()); return { paired: false };
}
async function pollAgent() {
  await restore();
  if (polling || !localAgent || !session) return;
  polling = true;
  let retry = false;
  const pairing = localAgent;
  try {
    const envelope = await agentFetch('/bridge/next');
    const command = envelope?.command;
    if (!command || typeof command.id !== 'string' || typeof command.action !== 'string') return;
    if (localAgent !== pairing || session?.id !== pairing.sessionId) return;
    let reply;
    const work = async () => {
      if (localAgent !== pairing || session?.id !== pairing.sessionId) throw failure('SESSION_CHANGED', 'The approved local agent session ended.');
      runningSource = 'agent';
      const known = ['status','audit','designSnapshot','screenshot','viewport','click','type','key','assertText','recordStart','recordStop','replay','stop','scroll','observe','inspect'].includes(command.action);
      const activityCommand = known ? command.action : 'unsupported';
      emit('activity', {source:'agent',command:activityCommand,status:'started'});
      try {
        const result = await dispatch(command.action, command.payload || {}, 'agent');
        emit('activity', {source:'agent',command:activityCommand,status:result?.passed === false ? 'failed' : 'passed'});
        return result;
      } catch (err) { emit('activity', {source:'agent',command:activityCommand,status:'failed',detail:err.code || 'BRIDGE_ERROR'}); throw err; }
      finally { if (runningSource === 'agent') runningSource = null; }
    };
    try { reply = { id: command.id, result: await (command.action === 'stop' ? work() : queued(work)) }; }
    catch (err) { reply = { id: command.id, error: { code: err.code || 'BRIDGE_ERROR', message: err.message || 'The browser command failed.' } }; }
    await agentFetch('/bridge/result', { method: 'POST', body: JSON.stringify(reply) }, 5000, pairing.token);
  } catch (err) {
    retry = true;
    if (localAgent === pairing && [401,403,409].includes(err.httpStatus)) await revokeAgentTransport(pairing, 'The local agent bridge revoked its pairing.');
  }
  finally {
    polling = false;
    if (localAgent && session) setTimeout(pollAgent, retry ? 5000 : 10);
  }
}
async function pollAgentControl() {
  await restore();
  if (controlPolling || !localAgent || !session) return;
  controlPolling = true;
  let retry = false;
  const pairing = localAgent;
  try {
    const envelope = await agentFetch('/bridge/control');
    const command = envelope?.command;
    if (!command || command.action !== 'stop' || typeof command.id !== 'string' || command.id.length > 100) return;
    if (localAgent !== pairing || session?.id !== pairing.sessionId) return;
    emit('activity', {source:'agent',command:'stop',status:'started'});
    let reply;
    try {
      const result = await dispatch('stop', {}, 'agent');
      reply = {id:command.id,result};
      emit('activity', {source:'agent',command:'stop',status:'passed'});
    } catch (err) {
      reply = {id:command.id,error:{code:err.code || 'BRIDGE_ERROR',message:err.message || 'Could not stop the browser session.'}};
      emit('activity', {source:'agent',command:'stop',status:'failed',detail:err.code || 'BRIDGE_ERROR'});
    }
    await agentFetch('/bridge/result', {method:'POST',body:JSON.stringify(reply)}, 5000, pairing.token);
  } catch (err) {
    retry = true;
    if (localAgent === pairing && (runningSource === 'agent' || [401,403,409].includes(err.httpStatus))) await revokeAgentTransport(pairing, 'The local agent control connection was lost.');
  }
  finally {
    controlPolling = false;
    if (localAgent && session) setTimeout(pollAgentControl, retry ? 5000 : 10);
  }
}
async function revokeAgentTransport(pairing, reason) {
  if (localAgent !== pairing) return;
  emit('activity', {source:'agent',command:'connection',status:'failed',detail:'Agent access revoked. Re-pair before continuing.'});
  // A separate dashboard command remains valid when only agent access expires.
  // If an agent action is running, invalidate its session before any next action.
  if (runningSource === 'agent') await end(`${reason} The active agent session was stopped.`);
  else await unpairAgent();
}
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'waypoint-agent-poll') { pollAgent(); pollAgentControl(); } });
chrome.runtime.onConnectExternal.addListener(port => {
  if (!trustedSender(port.sender) || port.name !== 'waypoint-dashboard') { port.disconnect(); return; }
  ports.add(port);
  if (!dashboardOwner) dashboardOwner = port;
  restore().then(() => { try { port.postMessage({ event: 'session', data: status() }); } catch (_) {} });
  port.onMessage.addListener(request => {
    if (!request || typeof request.id !== 'string' || request.id.length > 100 || typeof request.command !== 'string') return;
    const work = async () => {
      if (!ports.has(port)) throw failure('DISCONNECTED', 'The dashboard connection closed.');
      if (dashboardOwner !== port && !['status', 'stop'].includes(request.command)) throw failure('SESSION_BUSY', 'Another Waypoint dashboard owns this session. Close it before controlling this app.');
      runningSource = port;
      try { return await dispatch(request.command, request.payload || {}); } finally { if (runningSource === port) runningSource = null; }
    };
    const task = request.command === 'stop' ? work() : queued(work);
    task.then(result => { try { port.postMessage({ id: request.id, ok: true, result }); } catch (_) {} }, err => { try { port.postMessage({ id: request.id, ok: false, error: { code: err.code || 'BRIDGE_ERROR', message: err.message || 'The browser command failed.' } }); } catch (_) {} });
  });
  port.onDisconnect.addListener(() => {
    ports.delete(port);
    const wasOwner = dashboardOwner === port;
    if (dashboardOwner === port) dashboardOwner = ports.values().next().value || null;
    if (runningSource === port && session) { actionGeneration++; execute(() => { globalThis.WaypointEngine?.cancel?.(); }, [], 'inspect', session.id).catch(() => {}); }
    if (wasOwner && session?.recording && session.recordingBy !== 'agent') {
      session.recording = false; persist().catch(() => {});
      execute(() => { globalThis.WaypointEngine?.stopRecording?.(); }, [], 'inspect', session.id).catch(() => {});
      emit('recording', {recording:false,steps:session.steps,reason:'The controlling dashboard disconnected; recording stopped.'});
    }
  });
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request?.command === 'recordStep') {
    restore().then(async () => {
      if (!session?.recording || !session.consent.control || sender.id !== chrome.runtime.id || sender.tab?.id !== session.tabId || sender.frameId !== 0 || !sender.url || new URL(sender.url).origin !== session.origin || request.payload?.sessionId !== session.id || session.steps.length >= 100) return sendResponse({ok:false});
      let step;
      try { step = validateSteps([request.payload.step])[0]; } catch (_) { return sendResponse({ok:false}); }
      if (step.type !== 'click') return sendResponse({ok:false});
      session.steps.push(step); await persist(); emit('recording', { recording: true, steps: session.steps }); sendResponse({ok:true});
    }).catch(() => sendResponse({ok:false}));
    return true;
  }
  if (sender.id !== chrome.runtime.id || !sender.url?.startsWith(`chrome-extension://${chrome.runtime.id}/popup.html`)) return false;
  const work = request.command === 'authorize' ? () => authorize(request.payload || {}) : request.command === 'pairAgent' ? () => pairAgent(request.payload || {}) : request.command === 'unpairAgent' ? () => unpairAgent() : request.command === 'status' ? () => dispatch('status') : request.command === 'stop' ? () => end() : () => { throw failure('INVALID_REQUEST', 'Unknown popup command.'); };
  (['stop','unpairAgent'].includes(request.command) ? work() : queued(work)).then(result => sendResponse({ ok: true, result }), err => sendResponse({ ok: false, error: { code: err.code || 'BRIDGE_ERROR', message: err.message } }));
  return true;
});
chrome.tabs.onRemoved.addListener(tabId => { restore().then(() => { if (session?.tabId === tabId) end('The approved app tab was closed.'); }); });
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  restore().then(() => {
    if (session?.tabId !== tabId) return;
    if (changeInfo.url && new URL(changeInfo.url).origin !== session.origin) { end('The approved app left its authorized origin.'); return; }
    if (changeInfo.status === 'complete' && session.recording) {
      const expectedId = session.id;
      queued(() => session?.id === expectedId && session.recording ? startPageRecording(expectedId) : undefined).catch(() => { if (session?.id === expectedId) { session.recording = false; persist(); emit('recording', {recording:false,steps:session.steps,reason:'Recording paused because the document could not be inspected. Reconnect before continuing.'}); } });
    }
  });
});
chrome.debugger.onDetach.addListener((source, reason) => {
  restore().then(() => { if (session?.tabId === source.tabId) end(`Chrome debugger detached: ${reason}. Reconnect in the popup.`); });
});
chrome.debugger.onEvent.addListener((source, method, params) => {
  if (!session || source.tabId !== session.tabId) return;
  if (method === 'Page.frameNavigated' && params.frame && !params.frame.parentId) {
    try {
      if (new URL(params.frame.url).origin !== session.origin) { end('The approved app left its authorized origin.').catch(() => {}); return; }
      session.url = cleanUrl(params.frame.url);
    } catch (_) { end('The app navigation could not be verified.').catch(() => {}); }
    return;
  }
  if (method === 'Runtime.consoleAPICalled' && ['error', 'assert'].includes(params.type)) {
    telemetry.consoleErrors.push({ type: params.type, message: 'Console error emitted; arguments are intentionally not collected.', timestamp: new Date().toISOString() });
  } else if (method === 'Runtime.exceptionThrown') {
    telemetry.consoleErrors.push({ type: 'exception', message: 'Uncaught JavaScript exception.', url: cleanUrl(params.exceptionDetails?.url), timestamp: new Date().toISOString() });
  } else if (method === 'Network.requestWillBeSent') {
    if (pendingRequests.size > 500) pendingRequests.delete(pendingRequests.keys().next().value);
    pendingRequests.set(params.requestId, { url: cleanUrl(params.request?.url), type: params.type || 'Other' });
  } else if (method === 'Network.responseReceived' && params.response?.status >= 400) {
    telemetry.networkFailures.push({ url: cleanUrl(params.response.url), status: params.response.status, type: params.type, message: `HTTP ${params.response.status}`, timestamp: new Date().toISOString() });
  } else if (method === 'Network.loadingFailed') {
    const req = pendingRequests.get(params.requestId);
    telemetry.networkFailures.push({ url: req?.url || '', type: req?.type || params.type || 'Other', message: params.canceled ? 'Request canceled.' : String(params.errorText || 'Network request failed.').replace(/https?:\/\/\S+/g, '[URL]').slice(0, 120), timestamp: new Date().toISOString() });
    pendingRequests.delete(params.requestId);
  } else if (method === 'Network.loadingFinished') pendingRequests.delete(params.requestId);
  telemetry.consoleErrors = telemetry.consoleErrors.slice(-100); telemetry.networkFailures = telemetry.networkFailures.slice(-100);
});
