/* Explicit, guarded interaction. This is a journey runner, not an autonomous crawler. */
(function (root, factory) {
  if (!(typeof module === 'object' && module.exports) && root.WaypointEngine && root.WaypointEngine.version === 1) return;
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.WaypointEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const clean = value => String(value || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  const sensitiveAction = /\b(log\s*(?:in|out)|sign\s*(?:in|out|up)|login|logout|register|checkout|check\s*out|pay(?:ment)?|purchase|buy|order|delete|remove|destroy|erase|send|submit|publish|transfer|donate|subscribe|unsubscribe|confirm|accept\s+(?:offer|terms)|reset\s+password)\b/i;
  const sensitiveField = /password|passcode|\botp\b|one.?time|verification.?code|credit|card.?number|card.?holder|cc.?number|cc.?csc|cc.?exp|\bcvv\b|\bcvc\b|security.?code|\bssn\b|social.?security|secret|access.?token|api.?key|recovery|private.?key/i;
  const interactive = 'button,a[href],input,select,textarea,[role="button"],[role="link"],[contenteditable="true"],[contenteditable=""]';
  let recording = null;
  let recordingSink = null;
  let generation = 0;
  function deepActive(doc) {
    let el = doc.activeElement;
    while (el && el.shadowRoot && el.shadowRoot.activeElement) el = el.shadowRoot.activeElement;
    return el;
  }
  function label(el) {
    const doc = el.ownerDocument;
    const aria = clean(el.getAttribute('aria-label'));
    if (aria) return aria;
    const local = el.getRootNode();
    const labelledBy = (el.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean);
    const referenced = clean(labelledBy.map(id => {
      const found = typeof local.getElementById === 'function' ? local.getElementById(id) : doc.getElementById(id);
      return found ? found.textContent : '';
    }).join(' '));
    if (referenced) return referenced;
    if (el.labels && el.labels.length) return clean(Array.from(el.labels).map(x => x.textContent).join(' '));
    if (el.matches('input,textarea,select,[contenteditable]')) return clean(el.getAttribute('title')) || el.tagName.toLowerCase();
    const imageNames = Array.from(el.querySelectorAll('img[alt]')).map(img => img.getAttribute('alt') || '').join(' ');
    // Never use the value of input buttons or any form fields as an action name.
    return clean(el.textContent) || clean(imageNames) || clean(el.getAttribute('title')) || el.tagName.toLowerCase();
  }
  function namedTargets(text, doc) {
    const wanted = clean(text).toLocaleLowerCase('en-US');
    return Array.from(doc.querySelectorAll('button,a[href],input:not([type="hidden"]),select,textarea,[role="button"],[role="link"],[role="checkbox"],[role="switch"]'))
      .filter(el => isVisible(el, doc) && label(el).toLocaleLowerCase('en-US') === wanted);
  }
  function cssSelector(el, doc) {
    if (el.getRootNode() !== doc) return null;
    const esc = s => doc.defaultView.CSS && doc.defaultView.CSS.escape ? doc.defaultView.CSS.escape(s) : String(s).replace(/[^a-zA-Z0-9_-]/g, ch => '\\' + ch);
    if (el.id) {
      const candidate = '#' + esc(el.id);
      if (doc.querySelectorAll(candidate).length === 1) return candidate;
    }
    const bits = [];
    for (let p = el; p && p.nodeType === 1; p = p.parentElement) {
      let bit = p.tagName.toLowerCase();
      if (p.parentElement) bit += ':nth-child(' + (Array.from(p.parentElement.children).indexOf(p) + 1) + ')';
      bits.unshift(bit);
      if (bits.length > 12) return null;
    }
    return bits.join(' > ');
  }
  function ancestors(el) {
    const values = [];
    for (let p = el; p; p = p.parentElement || (p.getRootNode && p.getRootNode().host)) values.push(p);
    return values;
  }
  function isVisible(el, doc) {
    if (!el || !el.isConnected) return false;
    for (const p of ancestors(el)) {
      if (p.hasAttribute('hidden') || p.hasAttribute('inert') || p.getAttribute('aria-hidden') === 'true') return false;
      const s = doc.defaultView.getComputedStyle(p);
      if (s.display === 'none' || s.visibility === 'hidden' || s.visibility === 'collapse' || Number(s.opacity) === 0) return false;
    }
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  function fieldDescriptor(el) {
    // Read configuration only. Never inspect .value or attribute value.
    return ['type', 'name', 'id', 'autocomplete', 'aria-label', 'placeholder', 'data-testid'].map(k => el.getAttribute(k) || '').join(' ');
  }
  function verdict(el, {intent = 'click', key} = {}, doc = globalThis.document) {
    if (!el) return {safe: false, reason: 'No element was found at this location.'};
    if (!isVisible(el, doc)) return {safe: false, reason: 'The target is hidden, inert, or detached.'};
    const target = intent === 'click' ? el.closest(interactive) || el : el;
    const lineage = ancestors(target);
    if (lineage.some(p => p.matches(':disabled,[aria-disabled="true"]'))) return {safe: false, reason: 'The target is disabled.'};
    if (lineage.some(p => sensitiveField.test(fieldDescriptor(p)))) return {safe: false, reason: 'Sensitive fields require manual interaction in the app.'};
    if (target.matches('input[type="file"]')) return {safe: false, reason: 'File selection requires manual interaction in the app.'};
    const forms = lineage.filter(p => p.tagName === 'FORM');
    const authentication = forms.some(form => Array.from(form.querySelectorAll('input')).some(input => sensitiveField.test(fieldDescriptor(input))));
    if (intent === 'click' || key === 'Enter') {
      if (authentication) return {safe: false, reason: 'Authentication forms require manual interaction in the app.'};
      if (sensitiveAction.test(label(target)) || sensitiveAction.test([target.getAttribute('name'), target.getAttribute('id'), target.getAttribute('aria-label')].filter(Boolean).join(' '))) return {safe: false, reason: 'Sign-in, submission, sending, payment, or destructive actions require manual interaction in the app.'};
      if (target.matches('input[type="submit"],input[type="reset"],button[type="submit"],button[type="reset"]') || (target.tagName === 'BUTTON' && target.closest('form') && !target.getAttribute('type'))) return {safe: false, reason: 'Form submission or reset requires manual interaction in the app.'};
      if (key === 'Enter' && (target.closest('form') || target.matches('textarea,[contenteditable="true"],[contenteditable=""]'))) return {safe: false, reason: 'Enter may submit or send content; perform this action manually in the app.'};
      const link = target.closest('a[href]');
      if (link) {
        if (link.hasAttribute('download')) return {safe: false, reason: 'Downloads require manual interaction in the app.'};
        try {
          const url = new URL(link.getAttribute('href'), doc.location.href);
          if (sensitiveAction.test(decodeURIComponent(url.pathname).replace(/[\/_-]+/g, ' '))) return {safe: false, reason: 'The link leads to a sensitive action; navigate manually in the app.'};
          if (!/^https?:$/.test(url.protocol) || url.origin !== doc.location.origin) return {safe: false, reason: 'Only navigation within the authorized app origin is supported.'};
          if (link.target && link.target !== '_self') return {safe: false, reason: 'Opening another browsing context requires manual interaction.'};
        } catch { return {safe: false, reason: 'The link destination could not be verified.'}; }
      }
    }
    if (intent === 'type') {
      if (authentication) return {safe: false, reason: 'Authentication forms require manual interaction in the app.'};
      if (!target.matches('input,textarea,[contenteditable="true"],[contenteditable=""]')) return {safe: false, reason: 'Focus a non-sensitive text field before typing.'};
      if (target.matches('input') && !/^(text|search|email|url|tel)$/i.test(target.getAttribute('type') || 'text')) return {safe: false, reason: 'This input type is not supported for remote typing.'};
      if (target.readOnly) return {safe: false, reason: 'The field is read-only.'};
    }
    const r = target.getBoundingClientRect();
    return {safe: true, label: label(target), selector: cssSelector(target, doc), rectangle: {x:r.x,y:r.y,width:r.width,height:r.height}};
  }
  function inspectPoint({x, y}, doc = globalThis.document) {
    if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x >= doc.defaultView.innerWidth || y >= doc.defaultView.innerHeight) return {safe:false, reason:'Coordinates are outside the current viewport.'};
    let el = doc.elementFromPoint(x, y);
    while (el && el.shadowRoot && typeof el.shadowRoot.elementFromPoint === 'function') {
      const inner = el.shadowRoot.elementFromPoint(x, y);
      if (!inner || inner === el) break;
      el = inner;
    }
    return verdict(el, {intent:'click'}, doc);
  }
  function inspectFocus(options = {}, doc = globalThis.document) { return verdict(deepActive(doc), options, doc); }
  function startRecording(doc = globalThis.document) {
    stopRecording();
    const steps = [];
    const handler = event => {
      if (!event.isTrusted) return;
      const el = event.composedPath ? event.composedPath()[0] : event.target;
      const v = verdict(el, {intent:'click'}, doc);
      if (!v.safe || !v.selector || steps.length >= 100) return;
      const previous = steps[steps.length - 1];
      if (previous && previous.selector === v.selector && Date.now() - previous.recordedAt < 250) return;
      const step = {type:'click', selector:v.selector, label:v.label};
      steps.push({...step, recordedAt:Date.now()});
      if (recordingSink) { try { recordingSink({...step}); } catch { /* Recording remains local if the bridge disconnects. */ } }
    };
    doc.addEventListener('click', handler, true);
    recording = {doc, handler, steps};
    return {recording:true, steps:[]};
  }
  function setRecordingSink(sink) {
    if (sink !== null && typeof sink !== 'function') throw new Error('Recording sink must be a function or null.');
    recordingSink = sink;
    return {configured:!!sink};
  }
  function getRecording() {
    return {recording:!!recording, steps:recording ? recording.steps.map(({recordedAt, ...step}) => step) : []};
  }
  function stopRecording() {
    if (!recording) return {recording:false, steps:[]};
    const previous = recording;
    recording = null;
    previous.doc.removeEventListener('click', previous.handler, true);
    return {recording:false, steps:previous.steps.map(({recordedAt, ...step}) => step)};
  }
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  function textPresent(doc, text) {
    const wanted = String(text).replace(/\s+/g, ' ').trim();
    if (!wanted) return false;
    // TreeWalker skips text inside hidden controls and does not read input values.
    const walker = doc.createTreeWalker(doc.body || doc.documentElement, doc.defaultView.NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const parent = node.parentElement;
      if (!parent || parent.closest('script,style,noscript,template,input,textarea,select,[contenteditable]') || !isVisible(parent, doc)) continue;
      if (String(node.textContent).replace(/\s+/g, ' ').includes(wanted)) return true;
    }
    // Visible text can span child nodes; compare per visible element without body-wide hidden text.
    for (const el of doc.querySelectorAll('h1,h2,h3,h4,p,button,a,li,span,[role="status"],[role="alert"]')) {
      if (!isVisible(el, doc) || el.closest('input,textarea,select,[contenteditable]')) continue;
      const local = doc.createTreeWalker(el, doc.defaultView.NodeFilter.SHOW_TEXT);
      let part, visibleText = '';
      while ((part = local.nextNode())) if (part.parentElement && !part.parentElement.closest('script,style,noscript,template,input,textarea,select,[contenteditable]') && isVisible(part.parentElement, doc)) visibleText += ' ' + part.textContent;
      if (visibleText.replace(/\s+/g, ' ').includes(wanted)) return true;
    }
    return false;
  }
  function assertText({text}, doc = globalThis.document) {
    if (typeof text !== 'string' || !text.trim() || text.length > 300) throw new Error('Provide 1–300 characters of expected visible text.');
    const passed = textPresent(doc, text);
    return {passed, text, detail:passed ? 'Expected text is present in the visible page DOM.' : 'Expected text was not found in the visible page DOM.'};
  }
  async function run({steps, timeoutMs = 3000, delayMs = 300} = {}, doc = globalThis.document) {
    if (!Array.isArray(steps) || !steps.length || steps.length > 100) throw new Error('A journey requires 1–100 explicit click, named click, or text assertion steps.');
    // Validate all steps before the first mutation.
    for (const step of steps) {
      if (!step || !['click','clickText','assertText'].includes(step.type)) throw new Error('Only click, clickText and assertText journey steps are supported.');
      if (step.type === 'click' && (typeof step.selector !== 'string' || !step.selector.trim() || step.selector.length > 1000)) throw new Error('Click steps require a valid selector.');
      if (step.type === 'clickText' && (typeof step.text !== 'string' || !step.text.trim() || step.text.length > 300)) throw new Error('Named clicks require 1–300 characters of an exact control name.');
      if (step.type === 'assertText' && (typeof step.text !== 'string' || !step.text.trim() || step.text.length > 300)) throw new Error('Text assertions require 1–300 characters.');
      if (step.type === 'click') { try { doc.querySelectorAll(step.selector); } catch { throw new Error('A journey contains invalid selector syntax.'); } }
    }
    timeoutMs = Math.max(0, Math.min(10000, Number(timeoutMs) || 0));
    delayMs = Math.max(0, Math.min(3000, Number(delayMs) || 0));
    const token = ++generation, results = [];
    const initialOrigin = doc.location.origin;
    for (let index = 0; index < steps.length; index++) {
      if (token !== generation || doc.location.origin !== initialOrigin) { results.push({index, status:'blocked', detail:'Journey stopped or authorized origin changed.'}); break; }
      const step = steps[index], deadline = Date.now() + timeoutMs;
      let result;
      if (step.type === 'assertText') {
        do {
          result = assertText(step, doc);
          if (result.passed || Date.now() >= deadline || token !== generation) break;
          await sleep(Math.min(100, Math.max(0, deadline - Date.now())));
        } while (true);
        if (token !== generation) { results.push({index,status:'blocked',detail:'Journey was stopped.'}); break; }
        results.push({index, type:step.type, status:result.passed ? 'pass' : 'fail', detail:result.detail});
        if (!result.passed) break;
      } else {
        let targets;
        do {
          targets = step.type === 'clickText' ? namedTargets(step.text, doc) : Array.from(doc.querySelectorAll(step.selector)).filter(el => isVisible(el, doc));
          if (targets.length || Date.now() >= deadline || token !== generation) break;
          await sleep(Math.min(100, Math.max(0, deadline - Date.now())));
        } while (true);
        if (token !== generation) { results.push({index,status:'blocked',detail:'Journey was stopped.'}); break; }
        if (targets.length !== 1) { results.push({index,type:step.type,status:'fail',detail:targets.length ? 'Multiple visible controls match this step; use a unique control name or selector.' : 'No visible control matched this step.'}); break; }
        const el = targets[0], safe = verdict(el, {intent:'click'}, doc);
        if (!safe.safe) { results.push({index,type:step.type,status:'blocked',detail:safe.reason}); break; }
        if (step.label && clean(step.label) !== safe.label) { results.push({index,type:step.type,status:'blocked',detail:'Target label changed since recording. Re-record this step before replaying.'}); break; }
        el.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'});
        const r = el.getBoundingClientRect();
        const point = doc.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
        if (point && point !== el && !el.contains(point)) { results.push({index,type:step.type,status:'blocked',detail:'Another element covers the target; close the overlay or re-record.'}); break; }
        el.click();
        results.push({index,type:step.type,status:'pass',detail:'Clicked the explicitly selected safe control.',selector:safe.selector || step.selector});
      }
      if (index < steps.length - 1 && delayMs) await sleep(delayMs);
    }
    const passed = results.length === steps.length && results.every(r => r.status === 'pass');
    const status = passed ? 'passed' : results.some(r => r.status === 'blocked') ? 'blocked' : 'failed';
    return {passed, status, steps:results, results, findings:[]};
  }
  function cancel() { generation++; return {stopped:true}; }
  return {version:1, run, inspectPoint, inspectFocus, startRecording, stopRecording, getRecording, setRecordingSink, assertText, cancel, verdict, textPresent};
});
