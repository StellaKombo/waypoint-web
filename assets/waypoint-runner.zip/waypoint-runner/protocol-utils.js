/* Shared validation. No page values, credentials, or network bodies are stored. */
(function (root) {
  'use strict';
  const DASHBOARD_ORIGIN = 'https://waypoint-qa.hazyknoll5.chatgpt.site';
  const PRESETS = Object.freeze({
    desktop: { preset: 'desktop', width: 1440, height: 900, deviceScaleFactor: 1, mobile: false },
    mobile: { preset: 'mobile', width: 390, height: 844, deviceScaleFactor: 1, mobile: true }
  });
  function cleanUrl(value) {
    try { const u = new URL(value); return `${u.origin}${u.pathname}`; } catch (_) { return ''; }
  }
  function allowedOrigin(value) {
    try { const u = new URL(value); return ['https:', 'http:'].includes(u.protocol) && !u.username && !u.password && u.origin !== DASHBOARD_ORIGIN; } catch (_) { return false; }
  }
  function trustedSender(sender) {
    try { return new URL(sender?.url || sender?.origin || '').origin === DASHBOARD_ORIGIN; } catch (_) { return false; }
  }
  function boundedText(value, max = 1000, label = 'Text') {
    if (typeof value !== 'string' || !value.trim() || value.length > max) throw Object.assign(new Error(`${label} must contain 1–${max} characters.`), { code: 'INVALID_REQUEST' });
    return value;
  }
  function validateSteps(steps) {
    if (!Array.isArray(steps) || !steps.length || steps.length > 100) throw Object.assign(new Error('Choose 1–100 click or text assertion steps.'), { code: 'INVALID_REQUEST' });
    return steps.map((step, index) => {
      if (!step || !['click', 'clickText', 'assertText'].includes(step.type)) throw Object.assign(new Error(`Step ${index + 1} is unsupported. Only guarded clicks and visible text assertions can replay.`), { code: 'INVALID_REQUEST' });
      if (step.type === 'assertText') return { type: 'assertText', text: boundedText(step.text, 300, 'Assertion text') };
      if (step.type === 'clickText') return { type: 'clickText', text: boundedText(step.text, 300, 'Control name') };
      return { type: 'click', selector: boundedText(step.selector, 500, 'Selector'), label: typeof step.label === 'string' ? step.label.slice(0, 120) : '' };
    });
  }
  root.WaypointProtocol = { DASHBOARD_ORIGIN, PRESETS, cleanUrl, allowedOrigin, trustedSender, boundedText, validateSteps };
  if (typeof module !== 'undefined') module.exports = root.WaypointProtocol;
})(typeof globalThis !== 'undefined' ? globalThis : this);
