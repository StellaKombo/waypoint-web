'use strict';
const $ = id => document.getElementById(id);
let selectedTab;
function message(command, payload) {
  return new Promise((resolve, reject) => chrome.runtime.sendMessage({ command, payload }, response => {
    const error = chrome.runtime.lastError;
    if (error) reject(new Error(error.message));
    else if (!response?.ok) reject(new Error(response?.error?.message || 'Extension did not respond.'));
    else resolve(response.result);
  }));
}
function note(text, isError = false) { $('status').textContent = text; $('status').className = isError ? 'error' : ''; }
async function load() {
  $('extensionId').value = chrome.runtime.id;
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (chrome.runtime.lastError) { note(chrome.runtime.lastError.message, true); return; }
    selectedTab = tabs[0];
    try {
      const u = new URL(selectedTab?.url);
      if (!['http:', 'https:'].includes(u.protocol) || u.origin === 'https://waypoint-qa.hazyknoll5.chatgpt.site') throw new Error();
      $('selected').textContent = `${selectedTab.title || 'App tab'} · ${u.origin}`;
      $('connect').disabled = false;
    } catch (_) { $('selected').textContent = 'Open your app in an HTTP or HTTPS tab, then click this extension.'; }
  });
  try {
    const result = await message('status');
    $('stop').hidden = !result.connected;
    $('unpairAgent').hidden = !result.agentPaired;
    if (result.connected) note(`Connected to ${result.session.origin}. You can return to the dashboard.`);
  } catch (err) { note(err.message, true); }
}
$('consent').addEventListener('submit', async event => {
  event.preventDefault(); if (!selectedTab) return;
  $('connect').disabled = true; note('Connecting your approved app tab…');
  try {
    const result = await message('authorize', { tabId: selectedTab.id, consent: { inspect: $('inspect').checked, screenshot: $('screenshot').checked, control: $('control').checked } });
    note(`Connected to ${result.session.origin}. Return to Waypoint and connect using the ID below.`); $('stop').hidden = false;
  } catch (err) { note(err.message, true); } finally { $('connect').disabled = false; }
});
$('stop').addEventListener('click', async () => { try { await message('stop'); note('Session stopped.'); $('stop').hidden = true; } catch (err) { note(err.message, true); } });
$('copy').addEventListener('click', async () => { try { await navigator.clipboard.writeText(chrome.runtime.id); note('Extension ID copied.'); } catch (_) { $('extensionId').select(); note('Select and copy the extension ID.'); } });
$('pairAgent').addEventListener('click', async () => {
  $('pairAgent').disabled = true;
  try { await message('pairAgent', { token: $('agentToken').value.trim(), consent: $('agentConsent').checked }); $('agentToken').value = ''; $('unpairAgent').hidden = false; note('Local agent paired. It can now use your approved session through MCP.'); }
  catch (err) { note(err.message, true); } finally { $('pairAgent').disabled = false; }
});
$('unpairAgent').addEventListener('click', async () => { try { await message('unpairAgent'); $('unpairAgent').hidden = true; note('Local agent disconnected.'); } catch (err) { note(err.message, true); } });
load();
