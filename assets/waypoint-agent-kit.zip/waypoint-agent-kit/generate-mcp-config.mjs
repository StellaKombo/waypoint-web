#!/usr/bin/env node
/** Produce, never apply, independent Waypoint and official REA source registrations. */
import { realpath, readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const invalid = message => Object.assign(new Error(message), { code: 'MCP_CONFIG' });
const within = (root, target) => { const relative = path.relative(root, target); return relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative); };
async function canonicalFile(input, label) {
  if (typeof input !== 'string' || !path.isAbsolute(input) || /[\0\r\n]/.test(input)) throw invalid(`${label} must be an absolute local path.`);
  const file = await realpath(input);
  if (!(await stat(file)).isFile()) throw invalid(`${label} must refer to a regular file.`);
  return file;
}
export async function generateMcpConfig({ waypointServer, reaCheckout, nodeExecutable = process.execPath } = {}) {
  const node = await canonicalFile(nodeExecutable, 'Node executable');
  const waypoint = await canonicalFile(waypointServer, 'Waypoint server');
  if (typeof reaCheckout !== 'string' || !path.isAbsolute(reaCheckout) || /[\0\r\n]/.test(reaCheckout)) throw invalid('REA checkout must be an absolute local path.');
  const root = await realpath(reaCheckout);
  if (!(await stat(root)).isDirectory()) throw invalid('REA checkout must be a directory.');
  const packagePath = await canonicalFile(path.join(root, 'package.json'), 'REA package metadata');
  const script = await canonicalFile(path.join(root, 'scripts', 'rea.mjs'), 'REA MCP entry point');
  let runtime;
  try { runtime = await canonicalFile(path.join(root, 'dist', 'mcp', 'main.js'), 'Built REA MCP runtime'); }
  catch { throw invalid('Build the REA checkout with npm ci and npm run build:cached before generating its registration.'); }
  if (!within(root, packagePath) || !within(root, script) || !within(root, runtime)) throw invalid('REA metadata and entry point must stay inside the supplied checkout.');
  let metadata;
  try { metadata = JSON.parse(await readFile(packagePath, 'utf8')); } catch { throw invalid('REA package metadata must be valid JSON.'); }
  const repository = typeof metadata.repository === 'string' ? metadata.repository : metadata.repository?.url;
  if (metadata.name !== 'rea-agents' || typeof repository !== 'string' || repository.replace(/^git\+/, '').replace(/\/$/, '') !== 'https://github.com/morluto/rea.git') throw invalid('Use the official morluto/rea checkout with its rea-agents package metadata.');
  if (typeof metadata.version !== 'string' || !/^\d+\.\d+\.\d+(?:-[\w.-]+)?$/.test(metadata.version)) throw invalid('REA package metadata requires a valid version.');
  // Independent registration preserves the upstream MCP contract/capabilities.
  // Host policies, installed providers and the trusted checkout govern execution.
  return { mcpServers: { waypoint: { command: node, args: [waypoint] }, rea: { command: node, args: [script, 'mcp'] } } };
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const flags = new Map();
  try {
    const args = process.argv.slice(2);
    if (args.length % 2) throw invalid('Usage: node generate-mcp-config.mjs --waypoint /abs/server.mjs --rea-checkout /abs/rea [--node /abs/node]');
    for (let index = 0; index < args.length; index += 2) {
      if (!['--waypoint', '--rea-checkout', '--node'].includes(args[index]) || flags.has(args[index])) throw invalid('Unknown or repeated configuration option.');
      flags.set(args[index], args[index + 1]);
    }
    const config = await generateMcpConfig({ waypointServer: flags.get('--waypoint'), reaCheckout: flags.get('--rea-checkout'), nodeExecutable: flags.get('--node') || process.execPath });
    process.stdout.write(`${JSON.stringify(config, null, 2)}\n`);
  } catch (err) { process.stderr.write(`Could not generate MCP configuration: ${err.message}\n`); process.exitCode = 1; }
}
