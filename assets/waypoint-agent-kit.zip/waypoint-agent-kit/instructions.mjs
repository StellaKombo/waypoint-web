/** Deterministic human-readable test steps; no model keys or code execution. */
export function parseInstructions(instructions) {
  if (typeof instructions !== 'string' || instructions.length > 30000) throw new Error('Add up to 100 short test instructions.');
  const lines = instructions.split(/\r?\n/).map(line => line.trim().replace(/^\d+[.)]\s*/, '').replace(/^[-•]\s*/, '')).filter(Boolean);
  if (!lines.length || lines.length > 100) throw new Error('Add between 1 and 100 steps.');
  const target = (value, line) => {
    let valueText = value.trim();
    if (valueText.startsWith('"')) { try { valueText = JSON.parse(valueText); } catch { throw new Error(`Step ${line}: put the complete label inside double quotes.`); } }
    else if ((valueText.startsWith("'") && valueText.endsWith("'")) || (valueText.startsWith('“') && valueText.endsWith('”'))) valueText = valueText.slice(1, -1);
    if (typeof valueText !== 'string' || !valueText.trim() || valueText.length > 300 || /[\r\n]/.test(valueText)) throw new Error(`Step ${line}: use a visible label or text up to 300 characters.`);
    return valueText.trim();
  };
  return lines.map((line, index) => {
    const click = line.match(/^(?:click|tap|press)\s+(?:on\s+)?(.+)$/i);
    if (click) return { type: 'clickText', text: target(click[1], index + 1) };
    const check = line.match(/^(?:check|expect|verify|assert)\s+(?:that\s+)?(.+?)(?:\s+(?:is|to be|should be)\s+visible)?$/i);
    if (check) return { type: 'assertText', text: target(check[1], index + 1) };
    throw new Error(`Step ${index + 1}: write Click "button name" or Check "expected text" is visible. Use your connected AI agent for broader instructions.`);
  });
}
