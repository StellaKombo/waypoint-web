/** Dependency-free adapter for an explicitly attached, local Appium session. */
import { randomUUID } from 'node:crypto';
const ELEMENT_KEY = 'element-6066-11e4-a52e-4f735466cecf';
const MAX_SOURCE = 2 * 1024 * 1024;
const MAX_RESPONSE = 12 * 1024 * 1024;
const MAX_NODES = 400;
const SENSITIVE_ACTION = /\b(sign\s*(?:in|out|up)|log\s*(?:in|out)|login|logout|register|password|passcode|authenticate|delete|remove|erase|reset|purchase|buy|order|donate|download|pay|checkout|subscribe|send|submit|publish|transfer|invite|confirm|allow|grant|accept|install|uninstall)\b/i;
const PRIVATE_LABEL = /\b(password|passcode|secret|token|api key|verification code|one time (?:code|password)|otp|credit card|card number|cardholder|cc number|cvv|cvc|ssn|social security|routing number|bank account)\b/i;

export class NativeAdapterError extends Error {
  constructor(code, message) { super(message); this.name = 'NativeAdapterError'; this.code = code; }
}
function fail(code, message) { throw new NativeAdapterError(code, message); }
function boundedText(value, max = 500) { return typeof value === 'string' ? value.slice(0, max) : ''; }
function decodeXML(value) {
  return value.replace(/&(?:#x([0-9a-f]+)|#([0-9]+)|(amp|lt|gt|quot|apos));/gi, (match, hex, dec, name) => {
    if (hex || dec) { const n = parseInt(hex || dec, hex ? 16 : 10); return n > 0 && n <= 0x10ffff && !(n >= 0xd800 && n <= 0xdfff) ? String.fromCodePoint(n) : '\ufffd'; }
    return { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" }[name.toLowerCase()];
  });
}
function attributes(tag) {
  const result = {};
  for (const match of tag.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) result[match[1]] = decodeXML(match[2] ?? match[3]);
  return result;
}
function isPrivateAttributes(a, type) {
  const descriptor = [a.name, a.label, a['content-desc'], a['resource-id'], a.hint].filter(Boolean).join(' ').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[_-]+/g, ' ').replace(/\s+/g, ' ');
  return a.password === 'true' || a.secure === 'true' || /securetext|password/i.test(type) || PRIVATE_LABEL.test(descriptor);
}
function containsSecureFields(source) {
  for (const tag of source.match(/<(?:[^<>"']|"[^"]*"|'[^']*')*>/g) || []) {
    if (/^<[!?/]/.test(tag)) continue;
    const a = attributes(tag), type = a.type || a.class || /^<([\w.:-]+)/.exec(tag)?.[1] || '';
    if (isPrivateAttributes(a, type)) return true;
  }
  return false;
}
function rectFromAttributes(a) {
  const bounds = /^\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]$/.exec(a.bounds || '');
  const values = bounds ? [Number(bounds[1]), Number(bounds[2]), Number(bounds[3]) - Number(bounds[1]), Number(bounds[4]) - Number(bounds[2])] : [Number(a.x), Number(a.y), Number(a.width), Number(a.height)];
  return values.every(Number.isFinite) && values[2] > 0 && values[3] > 0 ? { x: values[0], y: values[1], width: values[2], height: values[3] } : null;
}

/** XML is bounded and never returned raw. Hidden and secure subtrees are excluded. */
export function parseNativeSource(source) {
  if (typeof source !== 'string' || source.length > MAX_SOURCE) fail('source_too_large', 'Native UI source exceeds the allowed limit.');
  if (/<!DOCTYPE|<!ENTITY/i.test(source)) fail('unsafe_xml', 'Native source must not contain XML entity declarations.');
  const nodes = [], stack = [];
  // Respect quoted '>' characters in attribute values rather than splitting a tag.
  for (const tag of source.match(/<(?:[^<>"']|"[^"]*"|'[^']*')*>/g) || []) {
    if (/^<\//.test(tag)) {
      const closingName = /^<\/([\w.:-]+)/.exec(tag)?.[1];
      if (stack.at(-1)?.tagName !== closingName) fail('invalid_xml', 'Native source contains mismatched XML elements.');
      stack.pop(); continue;
    }
    if (/^<[!?]/.test(tag)) continue;
    const a = attributes(tag);
    const type = a.type || a.class || (/^<([\w.:-]+)/.exec(tag)?.[1] ?? 'node');
    const hidden = stack.some(s => s.hidden) || a.visible === 'false' || a.displayed === 'false';
    const secure = stack.some(s => s.secure) || isPrivateAttributes(a, type);
    if (!/\/\s*>$/.test(tag)) {
      if (stack.length > 128) fail('source_too_deep', 'Native source nesting exceeds the allowed limit.');
      stack.push({ hidden, secure, tagName: /^<([\w.:-]+)/.exec(tag)?.[1] });
    }
    // Editable native fields can expose entered text through text, value or name.
    // Omit the complete field instead of guessing which driver attribute is safe.
    if (hidden || secure || /EditText|TextField|TextView.*(?:Editable|Input)|TextInput/i.test(type) || a.editable === 'true') continue;
    const labels = [...new Set([a['content-desc'], a.label, a.text, a.name, /(?:Text|Label)/i.test(type) ? a.value : undefined].filter(v => typeof v === 'string' && v.trim()).map(v => boundedText(v.trim())))];
    const rect = rectFromAttributes(a);
    if (!labels.length && !rect) continue;
    if (nodes.length >= MAX_NODES) break;
    nodes.push({ id: `node-${nodes.length + 1}`, type: boundedText(type, 100), labels, rect, enabled: a.enabled !== 'false', clickable: a.clickable === 'true' || /Button|Link|Tab|Switch|Cell/i.test(type), package: boundedText(a.package, 200) });
  }
  return nodes;
}

export function xpathLiteral(value) {
  if (!value.includes("'")) return `'${value}'`;
  if (!value.includes('"')) return `"${value}"`;
  return `concat(${value.split("'").map(part => `'${part}'`).join(',"\'",')})`;
}

function configure(env) {
  if (!env.WAYPOINT_APPIUM_URL || !env.WAYPOINT_APPIUM_SESSION_ID || !env.WAYPOINT_NATIVE_PLATFORM) return null;
  let url; try { url = new URL(env.WAYPOINT_APPIUM_URL); } catch { fail('invalid_configuration', 'WAYPOINT_APPIUM_URL must be a loopback HTTP URL.'); }
  if (url.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.username || url.password || url.search || url.hash) fail('invalid_configuration', 'Only local Appium HTTP URLs without credentials are supported.');
  const sessionId = env.WAYPOINT_APPIUM_SESSION_ID;
  if (!/^[A-Za-z0-9_-]{1,160}$/.test(sessionId)) fail('invalid_configuration', 'The Appium session ID is invalid.');
  const platform = env.WAYPOINT_NATIVE_PLATFORM.toLowerCase();
  if (!['android', 'ios'].includes(platform)) fail('invalid_configuration', 'Native platform must be Android or iOS.');
  return { url: url.href.replace(/\/$/, ''), sessionId, platform, expectedAppId: boundedText(env.WAYPOINT_NATIVE_APP_ID, 200) };
}

export function createNativeAdapter({ env = process.env, fetchImpl = globalThis.fetch, timeoutMs = 10000, operationTimeoutMs = Number(env.WAYPOINT_NATIVE_OPERATION_TIMEOUT_MS || 30000), replayTimeoutMs = Number(env.WAYPOINT_NATIVE_REPLAY_TIMEOUT_MS || 300000) } = {}) {
  for (const [name, value, max] of [['timeoutMs', timeoutMs, 30000], ['operationTimeoutMs', operationTimeoutMs, 300000], ['replayTimeoutMs', replayTimeoutMs, 300000]]) {
    if (!Number.isInteger(value) || value < 1 || value > max) fail('invalid_configuration', `${name} must be a positive integer no greater than ${max} milliseconds.`);
  }
  const config = configure(env);
  let stopped = false, active = false, connected = false, lastObservation = null, activeDeadline = 0, activeController = null, appId = config?.expectedAppId || null;
  const target = () => ({ kind: 'native', platform: config?.platform ?? null, appId });
  const status = () => ({ configured: !!config, attached: connected, transport: 'appium-existing-session', target: target(), stopped, realDeviceVerified: false, limits: { requestTimeoutMs: timeoutMs, operationTimeoutMs, replayTimeoutMs, targetStabilityMs: 100 } });
  function remainingBudget() {
    const remaining = activeDeadline - Date.now();
    if (remaining <= 0) fail('operation_timeout', 'The native operation reached its overall deadline; remaining steps were not executed.');
    return remaining;
  }
  async function sampleDelay() {
    if (stopped) fail('stopped', 'Native interaction has been stopped.');
    const remaining = remainingBudget();
    await new Promise(resolve => setTimeout(resolve, Math.min(100, remaining)));
    remainingBudget();
    if (stopped) fail('stopped', 'Native interaction has been stopped.');
  }
  async function request(method, suffix, body) {
    if (!config) fail('not_configured', 'Attach an existing local Appium session before using native tools.');
    if (stopped) fail('stopped', 'Native interaction has been stopped.');
    const remaining = remainingBudget(), budgetLimited = remaining <= timeoutMs;
    const controller = new AbortController();
    activeController = controller;
    const timer = setTimeout(() => controller.abort(), Math.min(timeoutMs, remaining));
    try {
      const response = await fetchImpl(`${config.url}/session/${encodeURIComponent(config.sessionId)}${suffix}`, {
        method, headers: { 'Content-Type': 'application/json' }, ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: controller.signal, redirect: 'error'
      });
      const reader = response.body?.getReader();
      let raw = '';
      if (reader) {
        const decoder = new TextDecoder(); let size = 0;
        while (true) { const { done, value } = await reader.read(); if (done) break; size += value.byteLength; if (size > MAX_RESPONSE) { await reader.cancel(); fail('response_too_large', 'Appium response exceeds the allowed limit.'); } raw += decoder.decode(value, { stream: true }); }
        raw += decoder.decode();
      } else { raw = await response.text(); if (raw.length > MAX_RESPONSE) fail('response_too_large', 'Appium response exceeds the allowed limit.'); }
      let parsed; try { parsed = JSON.parse(raw); } catch { fail('invalid_response', 'Appium returned an invalid JSON response.'); }
      if (!response.ok || parsed.value?.error) fail('webdriver_error', `Appium command failed (${response.status}${parsed.value?.error ? `, ${boundedText(parsed.value.error, 100)}` : ''}).`);
      if (stopped) fail('stopped', 'Native interaction has been stopped. An already submitted device action may finish.');
      remainingBudget();
      return parsed.value;
    } catch (error) {
      if (error instanceof NativeAdapterError) throw error;
      if (stopped && controller.signal.aborted) fail('stopped', 'Native interaction has been stopped. An already submitted device action may finish.');
      if (controller.signal.aborted && budgetLimited) fail('operation_timeout', 'The native operation reached its overall deadline; remaining steps were not executed.');
      fail(controller.signal.aborted ? 'timeout' : 'connection_failed', controller.signal.aborted ? 'Appium command timed out.' : 'Could not reach the configured local Appium session.');
    } finally { clearTimeout(timer); if (activeController === controller) activeController = null; }
  }
  async function observe() {
    const capabilities = await request('GET', '');
    const caps = capabilities?.capabilities || capabilities || {};
    const actualPlatform = String(caps.platformName || caps['appium:platformName'] || '').toLowerCase();
    if (actualPlatform && actualPlatform !== config.platform) fail('platform_mismatch', 'The attached session platform differs from the configured platform.');
    const detectedAppId = caps['appium:appPackage'] || caps.appPackage || caps['appium:bundleId'] || caps.bundleId;
    if (appId && detectedAppId && detectedAppId !== appId) fail('app_mismatch', 'The attached session app differs from its approved app identity.');
    if (detectedAppId) appId = boundedText(detectedAppId, 200);
    const source = await request('GET', '/source');
    const nodes = parseNativeSource(source);
    const hasSecureInputs = containsSecureFields(source);
    if (appId && config.platform === 'android') {
      const packages = [...new Set(nodes.map(n => n.package).filter(Boolean))];
      if (packages.length && !packages.includes(appId)) fail('app_mismatch', 'The foreground UI does not belong to the attached native app.');
    }
    let viewport;
    try { viewport = await request('GET', '/window/rect'); } catch (e) {
      // Some mobile drivers expose the legacy size endpoint instead of window rect.
      if (e.code !== 'webdriver_error') throw e;
      const size = await request('GET', '/window/current/size'); viewport = { x: 0, y: 0, ...size };
    }
    if (![viewport?.x, viewport?.y, viewport?.width, viewport?.height].every(Number.isFinite) || viewport.width <= 0 || viewport.height <= 0) fail('invalid_viewport', 'Appium did not return a valid native viewport.');
    const visibleNodes = nodes.filter(n => !n.rect || (n.rect.x + n.rect.width > viewport.x && n.rect.y + n.rect.height > viewport.y && n.rect.x < viewport.x + viewport.width && n.rect.y < viewport.y + viewport.height));
    connected = true;
    lastObservation = { target: target(), viewport, nodes: visibleNodes, hasSecureInputs, capturedAt: new Date().toISOString(), truncated: nodes.length >= MAX_NODES, privacy: 'Secure and editable fields excluded; ordinary visible labels may contain personal data.' };
    return lastObservation;
  }
  function exactNode(observation, text) {
    if (typeof text !== 'string' || !text.trim() || text.length > 500) fail('invalid_text', 'Provide an exact visible label of at most 500 characters.');
    const matches = observation.nodes.filter(n => n.labels.includes(text.trim()));
    if (!matches.length) fail('not_found', 'No visible native element matches that exact label.');
    if (matches.length !== 1) fail('ambiguous_target', 'Multiple native elements have this label; choose a unique visible label.');
    return matches[0];
  }
  async function clickText(text) {
    if (SENSITIVE_ACTION.test(String(text))) fail('manual_action_required', 'Complete authentication, permissions, messages, destructive actions and payments manually on the device.');
    const observation = await observe(), node = exactNode(observation, text);
    if (!appId) fail('app_identity_required', 'Set WAYPOINT_NATIVE_APP_ID or use a session advertising appPackage/bundleId before native interaction.');
    if (observation.hasSecureInputs) fail('manual_action_required', 'Complete screens containing authentication or payment fields manually on the device.');
    if (config.platform === 'android' && appId && node.package && node.package !== appId) fail('app_mismatch', 'This control belongs to a different native app or system overlay.');
    if (!node.enabled) fail('disabled_target', 'The matching native element is disabled.');
    if (!node.clickable) fail('manual_action_required', 'This element is not identified as a clickable control; use manual interaction.');
    if (node.labels.some(label => SENSITIVE_ACTION.test(label))) fail('manual_action_required', 'This control requires manual interaction on the device.');
    const value = `//*[@text=${xpathLiteral(text.trim())} or @label=${xpathLiteral(text.trim())} or @name=${xpathLiteral(text.trim())} or @content-desc=${xpathLiteral(text.trim())}]`;
    const elements = await request('POST', '/elements', { using: 'xpath', value });
    if (!Array.isArray(elements) || elements.length !== 1) fail('ambiguous_target', 'The driver could not identify one exact native target.');
    const elementId = elements[0][ELEMENT_KEY] || elements[0].ELEMENT;
    if (typeof elementId !== 'string' || !elementId) fail('invalid_response', 'Appium did not return a native element ID.');
    const route = `/element/${encodeURIComponent(elementId)}`;
    if (!(await request('GET', `${route}/displayed`)) || !(await request('GET', `${route}/enabled`))) fail('stale_target', 'The native target is no longer visible and enabled.');
    const rect = await request('GET', `${route}/rect`);
    if (!rect || !node.rect || ['x', 'y', 'width', 'height'].some(k => !Number.isFinite(rect[k]) || Math.abs(rect[k] - node.rect[k]) > 2)) fail('stale_target', 'The native target moved; observe the screen again before interaction.');
    await sampleDelay();
    const stableRect = await request('GET', `${route}/rect`);
    if (!stableRect || ['x', 'y', 'width', 'height'].some(k => !Number.isFinite(stableRect[k]) || Math.abs(stableRect[k] - rect[k]) > 2 || Math.abs(stableRect[k] - node.rect[k]) > 2)) fail('unstable_target', 'The native target is still moving; wait for the screen to settle before interacting.');
    if (stopped) fail('stopped', 'Native interaction has been stopped.');
    await request('POST', `${route}/click`, {});
    return { ok: true, action: 'clickText', text: text.trim(), target: target() };
  }
  async function scroll(direction = 'down') {
    if (!['up', 'down'].includes(direction)) fail('invalid_direction', 'Native scrolling supports up or down.');
    const observation = await observe(), v = observation.viewport;
    if (!appId) fail('app_identity_required', 'Set WAYPOINT_NATIVE_APP_ID or use a session advertising appPackage/bundleId before native interaction.');
    const x = Math.round(v.x + v.width / 2), top = Math.round(v.y + v.height * .25), bottom = Math.round(v.y + v.height * .75);
    if (stopped) fail('stopped', 'Native interaction has been stopped.');
    await request('POST', '/actions', { actions: [{ type: 'pointer', id: 'waypoint-touch', parameters: { pointerType: 'touch' }, actions: [{ type: 'pointerMove', duration: 0, origin: 'viewport', x, y: direction === 'down' ? bottom : top }, { type: 'pointerDown', button: 0 }, { type: 'pause', duration: 100 }, { type: 'pointerMove', duration: 400, origin: 'viewport', x, y: direction === 'down' ? top : bottom }, { type: 'pointerUp', button: 0 }] }] });
    return { ok: true, action: 'scroll', direction, target: target() };
  }
  async function perform(command) {
    const action = command?.action || command?.kind;
    if (action === 'status') return status();
    if (action === 'observe') return observe();
    if (action === 'screenshot') {
      const observation = await observe();
      const data = await request('GET', '/screenshot');
      if (typeof data !== 'string' || data.length > 10 * 1024 * 1024 || !/^[A-Za-z0-9+/=\r\n]+$/.test(data) || !data.startsWith('iVBOR')) fail('invalid_screenshot', 'Appium did not return a valid bounded PNG screenshot.');
      const png = Buffer.from(data, 'base64');
      if (png.length < 33 || !png.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) || png.toString('ascii', 12, 16) !== 'IHDR') fail('invalid_screenshot', 'Appium did not return a valid PNG header.');
      const width = png.readUInt32BE(16), height = png.readUInt32BE(20);
      if (!width || !height || width > 20000 || height > 20000) fail('invalid_screenshot', 'Appium screenshot dimensions exceed the allowed limit.');
      return { target: target(), mimeType: 'image/png', data, dataUrl: `data:image/png;base64,${data.replace(/[\r\n]/g, '')}`, width, height, viewport: observation.viewport, warning: 'Screenshots can expose personal data. Only capture authorized test devices.' };
    }
    if (action === 'clickText') return clickText(command.text);
    if (action === 'assertText') {
      if (typeof command.text !== 'string' || !command.text.trim() || command.text.length > 500) fail('invalid_text', 'Provide expected visible text of at most 500 characters.');
      const observation = await observe();
      if (!observation.nodes.some(n => n.labels.includes(command.text.trim()))) fail('not_found', 'Expected text was not present among the observed visible native UI labels.');
      return { ok: true, action, text: command.text.trim(), target: target() };
    }
    if (action === 'scroll') return scroll(command.direction);
    fail('unsupported_action', 'Supported native actions are observe, screenshot, clickText, assertText, scroll, replay, status and stop.');
  }
  async function execute(command = {}) {
    if (!command || typeof command !== 'object' || Array.isArray(command)) fail('invalid_command', 'Provide a structured native command.');
    const action = command.action || command.kind;
    if (action === 'stop') { stopped = true; activeController?.abort(); return { ok: true, stopped: true, target: target(), sessionPreserved: true, warning: 'An already submitted device action may finish.' }; }
    if (action === 'status') return status();
    if (!config) fail('not_configured', 'Attach an existing local Appium session before using native tools.');
    if (stopped) fail('stopped', 'Native interaction has been stopped. Restart the bridge to reattach.');
    if (active) fail('busy', 'A native command is already running. Wait for it to finish.');
    active = true;
    activeDeadline = Date.now() + (action === 'replay' ? replayTimeoutMs : operationTimeoutMs);
    try {
      if (action !== 'replay') return await perform(command);
      if (!Array.isArray(command.steps) || !command.steps.length || command.steps.length > 50) fail('invalid_steps', 'Provide between 1 and 50 structured native steps.');
      const allowed = new Set(['observe', 'screenshot', 'clickText', 'assertText', 'scroll']);
      if (command.steps.some(step => !step || !allowed.has(step.action || step.kind))) fail('unsupported_action', 'Replay contains an unsupported native step.');
      for (const step of command.steps) {
        const action = step.action || step.kind;
        if (['clickText', 'assertText'].includes(action) && (typeof step.text !== 'string' || !step.text.trim() || step.text.length > 500)) fail('invalid_text', 'Every native text step requires nonempty visible text of at most 500 characters.');
        if (action === 'scroll' && step.direction !== undefined && !['up', 'down'].includes(step.direction)) fail('invalid_direction', 'Every native scroll step must use up or down.');
      }
      const results = [], startedAt = new Date().toISOString();
      try { await observe(); }
      catch (error) {
        if (error.code !== 'operation_timeout' || !appId) throw error;
        results.push({ index: 0, action: command.steps[0].action || command.steps[0].kind, status: 'failed', error: { code: error.code, message: error.message } });
      }
      if (!appId) fail('app_identity_required', 'Set WAYPOINT_NATIVE_APP_ID or use a session advertising appPackage/bundleId before generating native reports.');
      for (const [index, step] of command.steps.entries()) {
        if (stopped || results.length && results.at(-1).status !== 'passed') break;
        const action = step.action || step.kind;
        try { results.push({ index, action, status: 'passed', result: await perform(step) }); }
        catch (error) { results.push({ index, action, status: error.code === 'manual_action_required' ? 'blocked' : 'failed', error: { code: error.code || 'native_error', message: error.message } }); break; }
      }
      const findings = [], checks = command.steps.map((step, index) => {
        const result = results.find(r => r.index === index), action = step.action || step.kind;
        const assertionFailed = action === 'assertText' && result?.error?.code === 'not_found';
        const name = `Step ${index + 1}: ${action}${step.text ? ` ${boundedText(step.text, 120)}` : ''}`;
        const status = !result ? 'not-tested' : result.status === 'passed' ? 'passed' : assertionFailed ? 'failed' : 'review';
        if (result && result.status !== 'passed') findings.push({ id: `native-step-${index + 1}`, rule: assertionFailed ? 'native-visible-text' : 'native-execution', category: 'native-journey', title: assertionFailed ? `Expected text was not observed: ${boundedText(step.text, 100)}` : `Native step ${index + 1} needs review`, kind: assertionFailed ? 'confirmed' : 'review', severity: assertionFailed ? 'medium' : 'low', detail: result.error.message, recommendation: assertionFailed ? 'Check that the expected screen is reached and its accessible visible text matches this test.' : 'Review the execution error, complete sensitive actions manually, and rerun the remaining steps.', evidence: { description: `Appium native UI observation at ${lastObservation?.capturedAt || startedAt}; ${result.error.code}.` }, status: 'open' });
        return { name, status, detail: result?.error?.message || (result ? 'Command completed against the attached Appium session.' : 'Not executed because the journey stopped before this step.') };
      });
      return { schema: 'waypoint.report.v1', schemaVersion: 1, id: `native-${randomUUID()}`, createdAt: startedAt, title: `Native ${config.platform === 'ios' ? 'iOS' : 'Android'} journey: ${appId}`, target: target(), viewport: lastObservation?.viewport || null, checks, findings, mode: 'native-attached-session', startedAt, completedAt: new Date().toISOString(), status: stopped ? 'stopped' : results.at(-1)?.status === 'passed' ? 'passed' : results.at(-1)?.status || 'blocked', results, coverage: { realDeviceVerified: false, note: 'This report describes only commands against the attached session; it is not complete functional or accessibility certification.' } };
    } finally { active = false; activeDeadline = 0; }
  }
  return { status, execute };
}
