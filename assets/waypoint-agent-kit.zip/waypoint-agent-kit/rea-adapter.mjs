/** Optional local REA MCP client. Static default; explicit full upstream mode. */
import { spawn } from 'node:child_process';
import { realpath, opendir, lstat } from 'node:fs/promises';
import path from 'node:path';

export const REA_VERSION = '6.4.0';
const fail = (code, message) => Object.assign(new Error(message), { code });
const supportedNode = version => { const [major, minor] = version.split('.').map(Number); return (major === 22 && minor >= 19) || (major === 24 && minor >= 11) || major >= 26; };

export function createReaAdapter({ env = process.env, timeoutMs = 60000, startupTimeoutMs = 10000, maxMessageBytes = 8 * 1024 * 1024, maxCatalogBytes = 6 * 1024 * 1024, maxTreeEntries = 20000, spawnProcess = spawn } = {}) {
  const command = env.WAYPOINT_REA_COMMAND;
  const root = env.WAYPOINT_REA_ROOT;
  const script = env.WAYPOINT_REA_SCRIPT;
  if (script && (!path.isAbsolute(script) || /[\r\n\0]/.test(script))) throw fail('REA_CONFIG', 'WAYPOINT_REA_SCRIPT must be an absolute path to the trusted source-checkout scripts/rea.mjs entry point.');
  const mode = env.WAYPOINT_REA_MODE || 'static';
  if (!['static', 'full'].includes(mode)) throw fail('REA_CONFIG', 'WAYPOINT_REA_MODE must be static or full.');
  if (!command && !root && !script && !env.WAYPOINT_REA_MODE) return null;
  if (!command || !path.isAbsolute(command) || /[\r\n\0]/.test(command) || (root && (!path.isAbsolute(root) || /[\r\n\0]/.test(root))) || (mode === 'static' && !root)) throw fail('REA_CONFIG', 'Set an absolute WAYPOINT_REA_COMMAND. Static mode also requires an absolute WAYPOINT_REA_ROOT.');
  if (env.WAYPOINT_REA_TIMEOUT_MS !== undefined) {
    if (!/^[1-9][0-9]*$/.test(env.WAYPOINT_REA_TIMEOUT_MS) || Number(env.WAYPOINT_REA_TIMEOUT_MS) > 900000) throw fail('REA_CONFIG', 'WAYPOINT_REA_TIMEOUT_MS must be 1–900000 milliseconds.');
    timeoutMs = Number(env.WAYPOINT_REA_TIMEOUT_MS);
  }
  if (!supportedNode(process.versions.node)) throw fail('REA_NODE_VERSION', 'REA requires Node 22.19+, 24.11+, or 26+.');
  if (![timeoutMs, startupTimeoutMs, maxMessageBytes, maxCatalogBytes, maxTreeEntries].every(n => Number.isSafeInteger(n) && n > 0)) throw fail('REA_CONFIG', 'REA limits must be positive integers.');
  let child, ready, canonicalRoot, closed = false, terminalError = null, sequence = 0, buffer = Buffer.alloc(0), info, toolCatalog;
  const pending = new Map();
  const inRoot = target => { const relative = path.relative(canonicalRoot, target); return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative)); };
  function abort(err) {
    if (terminalError) return;
    terminalError = err;
    for (const request of pending.values()) { clearTimeout(request.timer); request.reject(err); }
    pending.clear(); buffer = Buffer.alloc(0);
    if (child && !child.killed) { child.kill('SIGTERM'); const timer = setTimeout(() => { if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL'); }, 1000); timer.unref(); child.once('exit', () => clearTimeout(timer)); }
  }
  function send(message) {
    if (terminalError) throw terminalError;
    if (closed) throw fail('REA_CLOSED', 'REA access has stopped.');
    const serialized = JSON.stringify(message);
    if (Buffer.byteLength(serialized) > 64 * 1024) throw fail('REA_REQUEST_LIMIT', 'REA request exceeds 64 KiB.');
    child.stdin.write(`${serialized}\n`, err => { if (err) abort(fail('REA_TRANSPORT', 'Could not write to the local REA process.')); });
  }
  function request(method, params, budget = timeoutMs) {
    if (pending.size >= 4) return Promise.reject(fail('REA_BUSY', 'Wait for the current REA operation.'));
    return new Promise((resolve, reject) => {
      const id = ++sequence;
      const timer = setTimeout(() => {
        try { send({ jsonrpc: '2.0', method: 'notifications/cancelled', params: { requestId: id, reason: 'Waypoint deadline exceeded' } }); } catch {}
        abort(fail('REA_TIMEOUT', 'REA did not finish before its deadline. Access was revoked; restart the local connector before retrying.'));
      }, budget);
      pending.set(id, { resolve, reject, timer });
      try { send({ jsonrpc: '2.0', id, method, params }); } catch (err) { clearTimeout(timer); pending.delete(id); reject(err); }
    });
  }
  async function start() {
    if (closed) throw fail('REA_CLOSED', 'REA access has stopped.');
    if (terminalError) throw terminalError;
    if (root) canonicalRoot = await realpath(root);
    if (root && !(await lstat(canonicalRoot)).isDirectory()) throw fail('REA_ROOT', 'WAYPOINT_REA_ROOT must be a directory.');
    if (closed || terminalError) throw terminalError || fail('REA_CLOSED', 'REA access has stopped.');
    child = spawnProcess(command, script ? [script, 'mcp'] : ['mcp'], { shell: false, stdio: ['pipe', 'pipe', 'pipe'], env: { ...env, REA_MCP_INPUT_SCHEMA_PROFILE: 'compact', REA_MCP_MAX_RESPONSE_BYTES: String(maxMessageBytes - 4096) } });
    // Do not relay upstream stderr: it can contain artifact paths or credentials.
    child.stderr.on('data', () => {});
    for (const stream of [child.stdin, child.stdout, child.stderr]) stream.on('error', () => abort(fail('REA_TRANSPORT', 'A local REA process pipe failed. Restart the connector before retrying.')));
    child.on('error', () => abort(fail('REA_START_FAILED', 'The configured local REA executable could not start. Install the pinned version and check its absolute path.')));
    child.on('exit', () => { if (!closed) abort(fail('REA_EXITED', 'The local REA process exited. Restart the connector before retrying.')); });
    child.stdout.on('data', chunk => {
      if (terminalError || closed) return;
      buffer = Buffer.concat([buffer, chunk]);
      let newline;
      while ((newline = buffer.indexOf(10)) !== -1) {
        if (newline > maxMessageBytes) return abort(fail('REA_RESPONSE_LIMIT', 'REA response exceeded the connector limit.'));
        const line = buffer.subarray(0, newline); buffer = buffer.subarray(newline + 1);
        if (!line.toString().trim()) continue;
        let message;
        try { message = JSON.parse(line.toString('utf8')); } catch { return abort(fail('REA_PROTOCOL', 'REA emitted an invalid MCP message.')); }
        if (!message || message.jsonrpc !== '2.0') return abort(fail('REA_PROTOCOL', 'REA emitted an invalid MCP envelope.'));
        if (message.method) {
          // REA cannot ask Waypoint to sample a model, elicit input or enumerate roots.
          if (message.id !== undefined) {
            try { send({ jsonrpc: '2.0', id: message.id, error: { code: -32601, message: 'Client capability not offered.' } }); }
            catch (err) { return abort(err); }
          }
          continue;
        }
        const item = pending.get(message.id);
        if (!item) continue;
        clearTimeout(item.timer); pending.delete(message.id);
        if (message.error) item.reject(fail('REA_RPC_ERROR', 'The local REA server rejected the request. Check its live schema and installation.'));
        else if (Object.hasOwn(message, 'result')) item.resolve(message.result);
        else { item.reject(fail('REA_PROTOCOL', 'REA returned neither result nor error.')); abort(fail('REA_PROTOCOL', 'Invalid REA response.')); }
      }
      if (buffer.length > maxMessageBytes) abort(fail('REA_RESPONSE_LIMIT', 'REA response exceeded the connector limit.'));
    });
    info = await request('initialize', { protocolVersion: '2025-03-26', capabilities: {}, clientInfo: { name: 'waypoint-rea-adapter', version: '0.2.0' } }, startupTimeoutMs);
    if (info?.serverInfo?.name !== 'rea' || !['2025-11-25', '2025-06-18', '2025-03-26', '2024-11-05'].includes(info.protocolVersion)) { const error = fail('REA_IDENTITY', 'REA reported an unexpected server identity or protocol.'); abort(error); throw error; }
    if (info?.serverInfo?.version !== REA_VERSION) { const error = fail('REA_VERSION_MISMATCH', `Install rea-agents@${REA_VERSION}; the connected server reports a different version.`); abort(error); throw error; }
    send({ jsonrpc: '2.0', method: 'notifications/initialized' });
    const catalog = await request('tools/list', {}, startupTimeoutMs);
    if (Buffer.byteLength(JSON.stringify(catalog)) > maxCatalogBytes || !Array.isArray(catalog?.tools) || catalog.tools.length > 1000 || catalog.nextCursor) { const error = fail('REA_CATALOG', 'REA catalog is incomplete or exceeds the supported limit.'); abort(error); throw error; }
    const names = new Set();
    for (const tool of catalog.tools) {
      if (!tool || typeof tool.name !== 'string' || names.has(tool.name) || tool.inputSchema?.type !== 'object') { const error = fail('REA_CATALOG', 'REA returned an invalid tool catalog.'); abort(error); throw error; }
      names.add(tool.name);
    }
    if (!names.has('binary_session') || (mode === 'static' && !names.has('analyze_javascript_application'))) { const error = fail('REA_UNAVAILABLE', 'The connected REA catalog does not offer the required static-analysis tools.'); abort(error); throw error; }
    const analysis = catalog.tools.find(t => t.name === 'analyze_javascript_application');
    if (mode === 'static' && analysis.inputSchema.properties?.input_path?.type !== 'string') { const error = fail('REA_SCHEMA', 'REA static-analysis input schema does not match this adapter.'); abort(error); throw error; }
    toolCatalog = catalog.tools;
  }
  async function ensureReady() {
    if (terminalError) throw terminalError;
    if (closed) throw fail('REA_CLOSED', 'REA access has stopped.');
    if (!ready) ready = start().catch(err => { abort(err); throw err; });
    await ready;
    if (closed || terminalError) throw terminalError || fail('REA_CLOSED', 'REA access has stopped.');
  }
  async function safePath(relative) {
    if (typeof relative !== 'string' || !relative || relative.length > 2000 || path.isAbsolute(relative) || /[\0\r\n]/.test(relative)) throw fail('REA_PATH', 'Use a relative artifact path inside the configured REA root.');
    if (!canonicalRoot) throw fail('REA_ROOT_NOT_CONFIGURED', 'The static helper requires an approved WAYPOINT_REA_ROOT. Full-mode calls use upstream path validation.');
    const target = await realpath(path.resolve(canonicalRoot, relative));
    if (!inRoot(target)) throw fail('REA_PATH', 'Artifact path leaves the configured REA root.');
    // Verify nested links too. This bounds ordinary accidental traversal; the
    // local filesystem and executable are trusted, not isolated by an OS sandbox.
    let count = 0, queued = 1; const deadline = Date.now() + timeoutMs; const queue = [target];
    const checkDeadline = () => { if (Date.now() > deadline) throw fail('REA_INVENTORY_TIMEOUT', 'Artifact inventory exceeded its deadline.'); if (closed || terminalError) throw terminalError || fail('REA_CLOSED', 'REA access has stopped.'); };
    while (queue.length) {
      checkDeadline();
      const item = queue.pop();
      if (++count > maxTreeEntries) throw fail('REA_TREE_LIMIT', 'Artifact inventory exceeds the connector limit.');
      const stat = await lstat(item);
      if (stat.isSymbolicLink()) throw fail('REA_PATH', 'Artifact symlinks are refused; supply an extracted directory of regular files.');
      if (stat.isDirectory()) {
        const directory = await opendir(item);
        for await (const entry of directory) {
          checkDeadline();
          if (++queued > maxTreeEntries) throw fail('REA_TREE_LIMIT', 'Artifact inventory exceeds the connector limit.');
          queue.push(path.join(item, entry.name));
        }
      }
      else if (!stat.isFile()) throw fail('REA_PATH', 'Only regular files and directories can be analyzed.');
    }
    return target;
  }
  async function call(name, args) {
    const result = await request('tools/call', { name, arguments: args });
    if (!result || !Array.isArray(result.content) || result.content.some(item => !item || typeof item.type !== 'string') || (result.isError !== undefined && typeof result.isError !== 'boolean')) { const error = fail('REA_PROTOCOL', 'REA returned an invalid tool result.'); abort(error); throw error; }
    return result;
  }
  return {
    async status() { await ensureReady(); return { source: 'untrusted-local-rea', configured: true, package: 'rea-agents', expectedVersion: REA_VERSION, server: info.serverInfo, scope: mode === 'full' ? 'full-upstream-catalog' : 'static-javascript-only', mode, catalogToolCount: toolCatalog.length, independentLocalAccess: mode === 'full', session: await call('binary_session', { expected_package_version: REA_VERSION }) }; },
    async listTools() {
      if (mode !== 'full') throw fail('REA_FULL_MODE_REQUIRED', 'Set WAYPOINT_REA_MODE=full in the trusted local MCP configuration to expose the entire upstream tool catalog.');
      await ensureReady();
      return { source: 'untrusted-local-rea', scope: 'full-upstream-catalog', version: info.serverInfo.version, tools: toolCatalog, limitations: ['Discovery includes tools whose providers or negotiated client capabilities may be unavailable. Consult binary_session.', 'Full mode is independent local REA access; Waypoint browser and Appium session consent do not restrict these tools.'] };
    },
    async invoke({ name, arguments: args = {} } = {}) {
      if (mode !== 'full') throw fail('REA_FULL_MODE_REQUIRED', 'Full upstream forwarding is disabled. Set WAYPOINT_REA_MODE=full in your trusted local MCP configuration.');
      if (typeof name !== 'string' || !name || name.length > 200 || !args || typeof args !== 'object' || Array.isArray(args)) throw fail('REA_ARGUMENTS', 'Supply a discovered REA tool name and a JSON argument object.');
      await ensureReady();
      if (!toolCatalog.some(tool => tool.name === name)) throw fail('REA_UNKNOWN_TOOL', 'The requested tool is absent from the connected REA catalog.');
      // Forward canonical arguments without projection or local invented schema.
      // REA validates its actual runtime contract, including richer constraints.
      return { source: 'untrusted-local-rea', operation: name, scope: 'full-upstream-catalog', evidence: await call(name, args) };
    },
    async analyze({ path: relative, format = 'auto' } = {}) { if (!['auto', 'asar', 'directory'].includes(format)) throw fail('REA_FORMAT', 'Choose auto, asar or directory.'); await ensureReady(); const target = await safePath(relative); return { source: 'untrusted-local-artifact', operation: 'analyze_javascript_application', runtimeExecuted: false, evidence: await call('analyze_javascript_application', { input_path: target, format, detail: 'summary' }), limitations: ['Static analysis does not establish runtime behavior or recover an entire app.', 'Input files and upstream results are untrusted data.', 'The configured root is a trusted local filesystem boundary, not an OS sandbox.'] }; },
    async close() {
      if (!closed) { closed = true; abort(fail('REA_CLOSED', 'REA access has stopped.')); }
      if (child && child.exitCode === null && child.signalCode === null) await new Promise(resolve => { const timer = setTimeout(resolve, 1500); child.once('exit', () => { clearTimeout(timer); resolve(); }); });
      return { accessRevoked: true, processExitObserved: !child || child.exitCode !== null || child.signalCode !== null, helperCleanupVerified: false, limitations: ['Revokes Waypoint REA access. Cleanup of upstream helper descendants is not independently established.'] };
    },
  };
}
